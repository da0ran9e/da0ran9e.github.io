MY ALBUM - CHẠY TRÊN MÁY WINDOWS

Lần đầu:
1. Giải nén toàn bộ gói này.
2. Dừng cửa sổ server cũ đang dùng cổng 8000 bằng Ctrl+C.
3. Nhấp đúp start_my_album.cmd.
4. Chọn thư mục lớn đang chứa album.
5. Nếu Windows Firewall hỏi, chọn Allow access cho Private networks.

Những lần sau chỉ cần nhấp đúp start_my_album.cmd. Chương trình sẽ nhớ thư mục.

Đổi thư mục album:
- Nhấp đúp choose_album_folder.cmd.

Trên thiết bị xem album:
- Mở https://photos.vuducan.qzz.io/.
- Đăng nhập Cloudflare Access nếu được yêu cầu.
- Giao diện, API, thumbnail và tệp media đều chạy trên cùng subdomain nên không cần CORS.
- Mục My Album trên trang vuducan.qzz.io cũng mở trực tiếp địa chỉ này.

Cloudflare Tunnel:
- Tunnel photos.vuducan.qzz.io phải trỏ tới http://localhost:8000 trên máy Windows.
- Giữ cloudflared và cửa sổ My Album cùng hoạt động trong lúc xem.
- Không cần mở cổng 8000 trên router và không cần nhập IP LAN trong ứng dụng.

Kiểm tra server mới:
- Mở https://photos.vuducan.qzz.io/healthz sau khi đăng nhập.
- Kết quả đúng là JSON có trạng thái "ok" và apiVersion 7.
- Trên My Album, trạng thái kết nối phải là "Cloud API", không phải "Thư mục Cloud".

Dòng thời gian và bộ lọc:
- Album ưu tiên ngày chụp trong album-metadata.json; tệp chưa có metadata sẽ dùng ngày sửa đổi.
- Nút Lọc cho phép thu hẹp theo thư mục, máy ảnh, GPS, năm, tháng và ngày.
- Việc đọc mốc thời gian không làm thay đổi hoặc mở nội dung ảnh gốc.

Thư viện và thao tác:
- Mục Album tự gom ảnh và video theo thư mục, có ảnh bìa và số lượng mục.
- Có thể đánh dấu Yêu thích từ trình xem hoặc sau khi chọn nhiều tệp.
- Chọn nhiều tệp để Yêu thích, tải xuống, ẩn hoặc khôi phục.
- Yêu thích, Đã ẩn và kích thước thumbnail chỉ lưu trên trình duyệt/thiết bị hiện tại;
  các thao tác này không ghi hoặc sửa tệp trên server.

Xuất toàn bộ metadata ra JSON:
- Tải ExifTool cho Windows từ https://exiftool.org/ rồi đặt exiftool.exe và
  thư mục exiftool_files cạnh extract_album_metadata.py.
- Nhấp đúp extract_album_metadata.cmd. Script tự dùng thư mục album đã chọn.
- Kết quả là album-metadata.json trong thư mục gốc của album.
- Server tự đọc file này. Trạng thái kết nối hiện "EXIF" khi metadata đã được nhận.
- Sau khi chạy lại script, bấm Làm mới album để cập nhật ngày chụp và thông tin mới.
- Xem README_METADATA.txt để biết các tùy chọn quét và chạy lại.

Lưu ý:
- Giữ cửa sổ My Album mở trong lúc xem.
- Không mở port 8000 trên router.
- Server chỉ cho đọc. Ảnh và video gốc không bị thay đổi.
- Thumbnail và ảnh xem trước được lưu trong .my-album-cache của thư mục album.
