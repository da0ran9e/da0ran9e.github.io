#!/usr/bin/env python3
"""Serve a private, read-only photo and video album."""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import html
import json
import math
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from typing import Any, BinaryIO
from urllib.parse import parse_qs, urlsplit

from album_auth import (
    AuthConfig,
    LoginRateLimiter,
    create_session_token,
    load_auth_config,
    verify_password,
    verify_session_token,
)

try:
    from generate_thumbnails import create_thumbnail
except ModuleNotFoundError as error:
    if error.name == "PIL":
        print(
            "Pillow is required. Run: python3 -m pip install -r requirements.txt",
            file=sys.stderr,
        )
        raise SystemExit(2) from error
    raise


IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".gif",
    ".bmp",
    ".tif",
    ".tiff",
    ".heic",
    ".heif",
}
VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".webm", ".avi", ".mkv"}
SKIPPED_DIRECTORIES = {"thumbs", "_thumbnails", ".my-album-cache", "__pycache__"}
SORT_OPTIONS = {"newest", "oldest", "name-asc", "name-desc"}
LOCATION_FILTERS = {"all", "with", "without"}
METADATA_FILE_NAME = "album-metadata.json"
METADATA_DATE_TAGS = (
    "SubSecDateTimeOriginal",
    "DateTimeOriginal",
    "DateCreated",
    "CreateDate",
    "ContentCreateDate",
    "MediaCreateDate",
    "TrackCreateDate",
    "CreationDate",
    "ModifyDate",
)
METADATA_DATE_PATTERN = re.compile(
    r"(?P<year>\d{4})[:-](?P<month>\d{2})[:-](?P<day>\d{2})"
    r"(?:[ T](?P<hour>\d{2}):(?P<minute>\d{2}):(?P<second>\d{2}))?"
)
NUMBER_PATTERN = re.compile(r"[-+]?\d+(?:\.\d+)?")

mimetypes.add_type("image/heic", ".heic")
mimetypes.add_type("image/heif", ".heif")
mimetypes.add_type("video/mp4", ".m4v")
mimetypes.add_type("video/quicktime", ".mov")
mimetypes.add_type("video/x-matroska", ".mkv")


def encode_relative_path(relative_path: str) -> str:
    encoded = base64.urlsafe_b64encode(relative_path.encode("utf-8")).decode("ascii")
    return encoded.rstrip("=")


def decode_relative_path(token: str) -> str:
    if not token:
        raise ValueError("Missing media identifier")
    try:
        padded = token + "=" * (-len(token) % 4)
        decoded = base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
    except (ValueError, UnicodeError) as error:
        raise ValueError("Invalid media identifier") from error

    pure_path = PurePosixPath(decoded)
    if pure_path.is_absolute() or not pure_path.parts:
        raise ValueError("Invalid media path")
    if any(part in {"", ".", ".."} for part in pure_path.parts):
        raise ValueError("Invalid media path")
    return pure_path.as_posix()


def parse_byte_range(value: str | None, file_size: int) -> tuple[int, int] | None:
    if not value:
        return None
    if not value.startswith("bytes=") or "," in value:
        raise ValueError("Unsupported byte range")

    specification = value[6:].strip()
    if "-" not in specification:
        raise ValueError("Invalid byte range")
    start_text, end_text = specification.split("-", 1)

    if not start_text:
        suffix_length = int(end_text)
        if suffix_length <= 0:
            raise ValueError("Invalid suffix range")
        start = max(0, file_size - suffix_length)
        return start, file_size - 1

    start = int(start_text)
    end = int(end_text) if end_text else file_size - 1
    if start < 0 or start >= file_size or end < start:
        raise ValueError("Unsatisfiable byte range")
    return start, min(end, file_size - 1)


def human_file_type(path: Path) -> str | None:
    suffix = path.suffix.lower()
    if suffix in IMAGE_EXTENSIONS:
        return "image"
    if suffix in VIDEO_EXTENSIONS:
        return "video"
    return None


def metadata_tag_values(item: dict[str, Any]) -> dict[str, list[Any]]:
    tags: dict[str, list[Any]] = {}
    for key, value in item.items():
        if key == "_album":
            continue
        tag = str(key).rsplit(":", 1)[-1].casefold()
        tags.setdefault(tag, []).append(value)
    return tags


def scalar_text(value: Any, max_length: int = 300) -> str:
    if isinstance(value, bool):
        return "Có" if value else "Không"
    if isinstance(value, (int, float, str)):
        text = str(value).strip()
        return text[:max_length]
    return ""


def first_tag_value(tags: dict[str, list[Any]], *names: str) -> Any:
    for name in names:
        for value in tags.get(name.casefold(), []):
            if scalar_text(value):
                return value
    return None


def first_tag_text(
    tags: dict[str, list[Any]],
    *names: str,
    max_length: int = 300,
) -> str:
    return scalar_text(first_tag_value(tags, *names), max_length=max_length)


def numeric_value(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    text = scalar_text(value).replace(",", "")
    match = NUMBER_PATTERN.search(text)
    if match is None:
        return None
    try:
        number = float(match.group(0))
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def positive_integer(value: Any) -> int | None:
    number = numeric_value(value)
    if number is None:
        return None
    rounded = int(round(number))
    return rounded if rounded > 0 else None


def parse_coordinate(value: Any, reference: Any = None) -> float | None:
    if isinstance(value, bool):
        return None
    text = scalar_text(value)
    numbers = NUMBER_PATTERN.findall(text.replace(",", "."))
    if not numbers:
        return None
    try:
        parts = [float(number) for number in numbers[:3]]
    except ValueError:
        return None
    coordinate = abs(parts[0])
    if len(parts) > 1:
        coordinate += abs(parts[1]) / 60
    if len(parts) > 2:
        coordinate += abs(parts[2]) / 3600
    direction = f"{text} {scalar_text(reference)}".upper()
    if parts[0] < 0 or re.search(r"\b[SW]\b", direction):
        coordinate *= -1
    return round(coordinate, 7)


def parse_metadata_date(value: Any) -> tuple[int, str, str] | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            date = datetime.fromtimestamp(float(value))
        except (OSError, OverflowError, ValueError):
            return None
        return int(date.timestamp()), date.strftime("%Y-%m-%d"), date.strftime("%Y-%m-%d %H:%M:%S")

    text = scalar_text(value, max_length=100)
    match = METADATA_DATE_PATTERN.search(text)
    if match is None:
        return None
    try:
        date = datetime(
            int(match.group("year")),
            int(match.group("month")),
            int(match.group("day")),
            int(match.group("hour") or 0),
            int(match.group("minute") or 0),
            int(match.group("second") or 0),
        )
    except ValueError:
        return None
    return int(date.timestamp()), date.strftime("%Y-%m-%d"), date.strftime("%Y-%m-%d %H:%M:%S")


def camera_label(make: str, model: str) -> str:
    if not make:
        return model
    if not model:
        return make
    return model if model.casefold().startswith(make.casefold()) else f"{make} {model}"


def compact_metadata(item: dict[str, Any]) -> dict[str, object]:
    tags = metadata_tag_values(item)
    result: dict[str, object] = {"hasMetadata": True}
    metadata: dict[str, object] = {}

    for tag_name in METADATA_DATE_TAGS:
        for raw_date in tags.get(tag_name.casefold(), []):
            parsed_date = parse_metadata_date(raw_date)
            if parsed_date is None:
                continue
            timestamp, date_key, display = parsed_date
            result.update(
                {
                    "dateTaken": timestamp,
                    "dateKey": date_key,
                    "dateTakenText": display,
                    "dateSource": tag_name,
                }
            )
            break
        if result.get("dateTaken"):
            break

    make = first_tag_text(tags, "Make", max_length=100)
    model = first_tag_text(tags, "Model", "CameraModelName", max_length=140)
    camera = camera_label(make, model)
    lens = first_tag_text(tags, "LensModel", "Lens", "LensID", max_length=180)
    if make:
        metadata["make"] = make
    if model:
        metadata["model"] = model
    if camera:
        result["camera"] = camera
        metadata["camera"] = camera
    if lens:
        metadata["lens"] = lens

    text_fields = {
        "iso": ("ISO", "ISOSetting"),
        "aperture": ("FNumber", "Aperture"),
        "shutter": ("ExposureTime", "ShutterSpeed"),
        "focalLength": ("FocalLength", "FocalLengthIn35mmFormat"),
        "flash": ("Flash",),
        "duration": ("Duration", "TrackDuration", "MediaDuration"),
        "frameRate": ("VideoFrameRate", "VideoFrameRateMode"),
        "title": ("Title", "Headline", "ObjectName"),
        "description": ("Description", "Caption-Abstract", "ImageDescription"),
        "rating": ("Rating",),
    }
    for field, names in text_fields.items():
        value = first_tag_text(
            tags,
            *names,
            max_length=500 if field == "description" else 180,
        )
        if value:
            metadata[field] = value

    width = positive_integer(
        first_tag_value(tags, "ImageWidth", "ExifImageWidth", "SourceImageWidth", "VideoFrameWidth")
    )
    height = positive_integer(
        first_tag_value(tags, "ImageHeight", "ExifImageHeight", "SourceImageHeight", "VideoFrameHeight")
    )
    if (width is None or height is None):
        image_size = first_tag_text(tags, "ImageSize")
        size_match = re.search(r"(\d+)\s*[xX]\s*(\d+)", image_size)
        if size_match is not None:
            width = width or int(size_match.group(1))
            height = height or int(size_match.group(2))
    if width is not None:
        metadata["width"] = width
    if height is not None:
        metadata["height"] = height

    latitude = parse_coordinate(
        first_tag_value(tags, "GPSLatitude"),
        first_tag_value(tags, "GPSLatitudeRef"),
    )
    longitude = parse_coordinate(
        first_tag_value(tags, "GPSLongitude"),
        first_tag_value(tags, "GPSLongitudeRef"),
    )
    if latitude is not None and longitude is not None and abs(latitude) <= 90 and abs(longitude) <= 180:
        result["hasLocation"] = True
        metadata["latitude"] = latitude
        metadata["longitude"] = longitude
        altitude = numeric_value(first_tag_value(tags, "GPSAltitude"))
        if altitude is not None:
            metadata["altitude"] = round(altitude, 2)
    else:
        result["hasLocation"] = False

    result["metadata"] = metadata
    return result


@dataclass(frozen=True)
class AlbumConfig:
    source: Path
    cache: Path
    metadata: Path
    static: Path
    host: str
    port: int
    thumbnail_size: int
    thumbnail_quality: int
    preview_size: int
    preview_quality: int
    page_size: int
    auth: AuthConfig | None
    secure_cookie: bool
    cors_origins: tuple[str, ...]


class AlbumIndex:
    def __init__(self, config: AlbumConfig, cache_seconds: float = 300.0) -> None:
        self.config = config
        self.cache_seconds = cache_seconds
        self._items: list[dict[str, object]] = []
        self._last_scan = 0.0
        self._metadata_signature: tuple[int, int] | None = None
        self._metadata_by_path: dict[str, dict[str, object]] = {}
        self._metadata_status: dict[str, object] = {
            "available": False,
            "items": 0,
            "generatedAt": "",
        }
        self._lock = threading.Lock()

    def invalidate(self) -> None:
        with self._lock:
            self._last_scan = 0.0

    def _load_metadata(self) -> dict[str, dict[str, object]]:
        path = self.config.metadata
        try:
            stat = path.stat()
        except OSError:
            self._metadata_signature = None
            self._metadata_by_path = {}
            self._metadata_status = {
                "available": False,
                "items": 0,
                "generatedAt": "",
            }
            return self._metadata_by_path

        signature = (stat.st_mtime_ns, stat.st_size)
        if signature == self._metadata_signature:
            return self._metadata_by_path

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            raw_items = payload.get("items") if isinstance(payload, dict) else None
            if not isinstance(raw_items, list):
                raise ValueError("metadata JSON không có danh sách items")

            indexed: dict[str, dict[str, object]] = {}
            for raw_item in raw_items:
                if not isinstance(raw_item, dict):
                    continue
                album = raw_item.get("_album")
                relative = album.get("path") if isinstance(album, dict) else None
                if not isinstance(relative, str):
                    continue
                normalized = PurePosixPath(relative.replace("\\", "/")).as_posix()
                pure_path = PurePosixPath(normalized)
                if pure_path.is_absolute() or any(part in {"", ".", ".."} for part in pure_path.parts):
                    continue
                indexed[normalized] = compact_metadata(raw_item)

            generated_at = payload.get("generatedAt", "") if isinstance(payload, dict) else ""
            self._metadata_signature = signature
            self._metadata_by_path = indexed
            self._metadata_status = {
                "available": True,
                "items": len(indexed),
                "generatedAt": generated_at if isinstance(generated_at, str) else "",
            }
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as error:
            self._metadata_signature = signature
            self._metadata_by_path = {}
            self._metadata_status = {
                "available": False,
                "items": 0,
                "generatedAt": "",
                "error": str(error)[:240],
            }
            print(f"Metadata: cannot read {path} ({error})", file=sys.stderr)
        return self._metadata_by_path

    def metadata_status(self) -> dict[str, object]:
        with self._lock:
            self._load_metadata()
            return dict(self._metadata_status)

    def _scan(self) -> list[dict[str, object]]:
        items: list[dict[str, object]] = []
        metadata_by_path = self._load_metadata()
        for root, directory_names, file_names in os.walk(self.config.source):
            directory_names[:] = [
                name
                for name in directory_names
                if name.casefold() not in SKIPPED_DIRECTORIES and not name.startswith(".")
            ]
            root_path = Path(root)
            for file_name in file_names:
                if file_name.startswith("."):
                    continue
                path = root_path / file_name
                media_type = human_file_type(path)
                if media_type is None:
                    continue
                try:
                    stat = path.stat()
                except OSError:
                    continue
                if not path.is_file() or stat.st_size <= 0:
                    continue

                relative = path.relative_to(self.config.source).as_posix()
                token = encode_relative_path(relative)
                item: dict[str, object] = {
                    "id": token,
                    "name": path.stem,
                    "fileName": path.name,
                    "folder": path.parent.relative_to(self.config.source).as_posix(),
                    "type": media_type,
                    "extension": path.suffix.lower().lstrip("."),
                    "bytes": stat.st_size,
                    "modified": int(stat.st_mtime),
                    "thumbnail": f"/thumbnail/{token}",
                    "view": f"/preview/{token}",
                    "media": f"/media/{token}",
                }
                item.update(metadata_by_path.get(relative, {}))
                items.append(item)
        return items

    def all_items(self, force: bool = False) -> list[dict[str, object]]:
        with self._lock:
            now = time.monotonic()
            if force or now - self._last_scan >= self.cache_seconds:
                self._items = self._scan()
                self._last_scan = now
            return list(self._items)

    def query(
        self,
        *,
        offset: int,
        limit: int,
        media_type: str,
        search: str,
        sort: str,
        folder: str,
        camera: str,
        location: str,
        year: int,
        month: int,
        day: int,
        include_facets: bool,
        force: bool,
    ) -> dict[str, object]:
        items = self.all_items(force=force)
        stats = {
            "total": len(items),
            "images": sum(item["type"] == "image" for item in items),
            "videos": sum(item["type"] == "video" for item in items),
            "metadata": sum(bool(item.get("hasMetadata")) for item in items),
            "captured": sum(bool(item.get("dateTaken")) for item in items),
            "locations": sum(bool(item.get("hasLocation")) for item in items),
        }
        if media_type in {"image", "video"}:
            items = [item for item in items if item["type"] == media_type]
        if search:
            folded_search = search.casefold()
            matching_items = []
            for item in items:
                metadata = item.get("metadata")
                metadata_text = ""
                if isinstance(metadata, dict):
                    metadata_text = " ".join(
                        scalar_text(value, max_length=500)
                        for value in metadata.values()
                        if scalar_text(value, max_length=500)
                    )
                haystack = (
                    f"{item['name']} {item['fileName']} {item['folder']} "
                    f"{item.get('camera', '')} {metadata_text}"
                )
                if folded_search in haystack.casefold():
                    matching_items.append(item)
            items = matching_items

        def item_timestamp(item: dict[str, object]) -> int:
            return int(item.get("dateTaken") or item["modified"])

        def item_date_key(item: dict[str, object]) -> str:
            date_key = item.get("dateKey")
            if isinstance(date_key, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_key):
                return date_key
            return datetime.fromtimestamp(int(item["modified"])).strftime("%Y-%m-%d")

        facets = None
        if include_facets:
            facets = {
                "folders": sorted(
                    {str(item["folder"]) for item in items},
                    key=str.casefold,
                ),
                "dates": sorted(
                    {item_date_key(item) for item in items},
                    reverse=True,
                ),
                "cameras": sorted(
                    {str(item["camera"]) for item in items if item.get("camera")},
                    key=str.casefold,
                ),
                "locations": {
                    "with": sum(bool(item.get("hasLocation")) for item in items),
                    "without": sum(not bool(item.get("hasLocation")) for item in items),
                },
                "metadata": sum(bool(item.get("hasMetadata")) for item in items),
            }

        if folder:
            items = [item for item in items if item["folder"] == folder]
        if camera:
            items = [item for item in items if item.get("camera") == camera]
        if location == "with":
            items = [item for item in items if item.get("hasLocation")]
        elif location == "without":
            items = [item for item in items if not item.get("hasLocation")]
        if year:
            items = [item for item in items if item_date_key(item).startswith(f"{year:04d}-")]
        if month:
            items = [item for item in items if item_date_key(item)[5:7] == f"{month:02d}"]
        if day:
            items = [item for item in items if item_date_key(item)[8:10] == f"{day:02d}"]

        if sort == "oldest":
            items.sort(key=lambda item: (item_timestamp(item), str(item["fileName"]).casefold()))
        elif sort == "name-asc":
            items.sort(key=lambda item: (str(item["fileName"]).casefold(), -item_timestamp(item)))
        elif sort == "name-desc":
            items.sort(
                key=lambda item: (str(item["fileName"]).casefold(), item_timestamp(item)),
                reverse=True,
            )
        else:
            items.sort(
                key=lambda item: (item_timestamp(item), str(item["fileName"]).casefold()),
                reverse=True,
            )

        total = len(items)
        page = items[offset : offset + limit]
        payload = {
            "items": page,
            "offset": offset,
            "limit": limit,
            "total": total,
            "hasMore": offset + len(page) < total,
            "stats": stats,
            "metadata": dict(self._metadata_status),
        }
        if facets is not None:
            payload["facets"] = facets
        return payload


class AlbumHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], config: AlbumConfig) -> None:
        super().__init__(address, AlbumRequestHandler)
        self.album_config = config
        self.album_index = AlbumIndex(config)
        self.login_limiter = LoginRateLimiter()


class AlbumRequestHandler(BaseHTTPRequestHandler):
    server: AlbumHTTPServer
    protocol_version = "HTTP/1.1"
    server_version = "MyAlbum"
    sys_version = ""

    def do_HEAD(self) -> None:
        self._route(send_body=False)

    def do_GET(self) -> None:
        self._route(send_body=True)

    def do_OPTIONS(self) -> None:
        if self._allowed_cors_origin() is None:
            self.send_response(HTTPStatus.FORBIDDEN)
            self._send_common_headers(cache_control="no-store")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        self.send_response(HTTPStatus.NO_CONTENT)
        self._send_common_headers(cache_control="no-store")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Accept, Range")
        self.send_header("Access-Control-Max-Age", "7200")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self) -> None:
        request = urlsplit(self.path)
        if request.path != "/login" or self.server.album_config.auth is None:
            self.send_response(HTTPStatus.METHOD_NOT_ALLOWED)
            self._send_common_headers(cache_control="no-store")
            self.send_header("Allow", "GET, HEAD, OPTIONS")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self._handle_login()

    def _route(self, *, send_body: bool) -> None:
        request = urlsplit(self.path)
        path = request.path
        try:
            if path == "/healthz":
                self._send_json(
                    {
                        "status": "ok",
                        "apiVersion": 7,
                        "metadata": self.server.album_index.metadata_status(),
                    },
                    send_body=send_body,
                )
                return
            if path in {"/assets/styles.css", "/styles.css"}:
                self._serve_static("styles.css", send_body=send_body)
                return
            if path == "/login" and self.server.album_config.auth is not None:
                if self._is_authenticated():
                    self._send_redirect("/")
                else:
                    self._serve_login(send_body=send_body)
                return
            if path == "/logout" and self.server.album_config.auth is not None:
                self._send_redirect("/login", clear_session=True)
                return
            if self.server.album_config.auth is not None and not self._is_authenticated():
                self._send_unauthorized(path, send_body=send_body)
                return
            if path in {"/", "/index.html"}:
                self._serve_static("index.html", send_body=send_body)
                return
            if path in {"/assets/app.js", "/app.js"}:
                self._serve_static("app.js", send_body=send_body)
                return
            if path == "/sw.js":
                self._serve_static("sw.js", send_body=send_body)
                return
            if path == "/api/items":
                self._serve_items(parse_qs(request.query), send_body=send_body)
                return
            if path == "/api/session":
                auth = self.server.album_config.auth
                self._send_json(
                    {
                        "authenticated": bool(auth),
                        "email": auth.email if auth else "Chế độ cục bộ",
                    },
                    send_body=send_body,
                )
                return
            if path.startswith("/thumbnail/"):
                self._serve_thumbnail(path.removeprefix("/thumbnail/"), send_body=send_body)
                return
            if path.startswith("/preview/"):
                self._serve_preview(path.removeprefix("/preview/"), send_body=send_body)
                return
            if path.startswith("/media/"):
                self._serve_media(path.removeprefix("/media/"), send_body=send_body)
                return
            self._send_error(HTTPStatus.NOT_FOUND, "Không tìm thấy")
        except BrokenPipeError:
            return
        except (OSError, ValueError) as error:
            self._send_error(HTTPStatus.BAD_REQUEST, str(error))

    def _client_key(self) -> str:
        forwarded = self.headers.get("CF-Connecting-IP", "").strip()
        return forwarded or self.client_address[0]

    def _session_cookie(self) -> str | None:
        auth = self.server.album_config.auth
        if auth is None:
            return None
        try:
            cookies = SimpleCookie()
            cookies.load(self.headers.get("Cookie", ""))
            morsel = cookies.get(auth.cookie_name)
            return morsel.value if morsel else None
        except CookieError:
            return None

    def _is_authenticated(self) -> bool:
        auth = self.server.album_config.auth
        if auth is None:
            return True
        token = self._session_cookie()
        return bool(token and verify_session_token(auth, token))

    def _handle_login(self) -> None:
        auth = self.server.album_config.auth
        if auth is None:
            self._send_error(HTTPStatus.NOT_FOUND, "Không tìm thấy")
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            content_length = 0
        if not 1 <= content_length <= 8192:
            self._serve_login(
                message="Yêu cầu đăng nhập không hợp lệ.",
                status=HTTPStatus.BAD_REQUEST,
            )
            return

        client_key = self._client_key()
        if not self.server.login_limiter.allowed(client_key):
            self._serve_login(
                message="Đã thử quá nhiều lần. Vui lòng thử lại sau.",
                status=HTTPStatus.TOO_MANY_REQUESTS,
            )
            return

        try:
            body = self.rfile.read(content_length).decode("utf-8")
            fields = parse_qs(body, keep_blank_values=True)
            email = fields.get("email", [""])[0].strip().casefold()
            password = fields.get("password", [""])[0]
        except UnicodeError:
            email, password = "", ""

        email_matches = hmac.compare_digest(email, auth.email)
        password_matches = verify_password(password, auth.password_hash)
        if email_matches and password_matches:
            self.server.login_limiter.clear(client_key)
            self._send_redirect("/", session_token=create_session_token(auth))
            return

        self.server.login_limiter.record_failure(client_key)
        self._serve_login(
            message="Email hoặc mật khẩu không đúng.",
            status=HTTPStatus.UNAUTHORIZED,
        )

    def _serve_login(
        self,
        *,
        message: str = "",
        status: HTTPStatus = HTTPStatus.OK,
        send_body: bool = True,
    ) -> None:
        template = (self.server.album_config.static / "login.html").read_text(encoding="utf-8")
        body = (
            template.replace("{{ERROR_MESSAGE}}", html.escape(message))
            .replace("{{ERROR_HIDDEN}}", "" if message else "hidden")
            .encode("utf-8")
        )
        self.send_response(status)
        self._send_common_headers(cache_control="no-store")
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if send_body:
            self.wfile.write(body)

    def _send_unauthorized(self, path: str, *, send_body: bool) -> None:
        accepts_html = "text/html" in self.headers.get("Accept", "")
        if path in {"/", "/index.html"} or accepts_html:
            self._send_redirect("/login")
            return
        body = json.dumps({"error": "Phiên đăng nhập đã hết hạn."}, ensure_ascii=False).encode(
            "utf-8"
        )
        self.send_response(HTTPStatus.UNAUTHORIZED)
        self._send_common_headers(cache_control="no-store")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if send_body:
            self.wfile.write(body)

    def _send_redirect(
        self,
        location: str,
        *,
        session_token: str | None = None,
        clear_session: bool = False,
    ) -> None:
        auth = self.server.album_config.auth
        self.send_response(HTTPStatus.SEE_OTHER)
        self._send_common_headers(cache_control="no-store")
        self.send_header("Location", location)
        if auth and (session_token is not None or clear_session):
            value = session_token or ""
            max_age = auth.session_hours * 3600 if session_token else 0
            cookie = (
                f"{auth.cookie_name}={value}; Path=/; Max-Age={max_age}; "
                "HttpOnly; SameSite=Strict"
            )
            if self.server.album_config.secure_cookie:
                cookie += "; Secure"
            self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _serve_items(self, query: dict[str, list[str]], *, send_body: bool) -> None:
        config = self.server.album_config

        def first(name: str, fallback: str) -> str:
            values = query.get(name)
            return values[0] if values else fallback

        try:
            offset = max(0, int(first("offset", "0")))
            limit = min(200, max(1, int(first("limit", str(config.page_size)))))
            year = max(0, int(first("year", "0")))
            month = max(0, int(first("month", "0")))
            day = max(0, int(first("day", "0")))
        except ValueError as error:
            raise ValueError("Thông số phân trang và thời gian phải là số") from error

        media_type = first("type", "all")
        sort = first("sort", "newest")
        location = first("location", "all")
        if media_type not in {"all", "image", "video"}:
            raise ValueError("Bộ lọc không hợp lệ")
        if sort not in SORT_OPTIONS:
            raise ValueError("Kiểu sắp xếp không hợp lệ")
        if location not in LOCATION_FILTERS:
            raise ValueError("Bộ lọc vị trí không hợp lệ")
        if year and not 1900 <= year <= 9999:
            raise ValueError("Năm không hợp lệ")
        if not 0 <= month <= 12 or (month and not year):
            raise ValueError("Tháng không hợp lệ")
        if not 0 <= day <= 31 or (day and not month):
            raise ValueError("Ngày không hợp lệ")

        payload = self.server.album_index.query(
            offset=offset,
            limit=limit,
            media_type=media_type,
            search=first("q", "").strip()[:200],
            sort=sort,
            folder=first("folder", "").strip()[:1000],
            camera=first("camera", "").strip()[:300],
            location=location,
            year=year,
            month=month,
            day=day,
            include_facets=offset == 0,
            force=first("refresh", "0") == "1",
        )
        self._send_json(payload, send_body=send_body)

    def _resolve_media(self, token: str) -> tuple[Path, str]:
        relative = decode_relative_path(token)
        source = self.server.album_config.source
        candidate = (source / Path(*PurePosixPath(relative).parts)).resolve(strict=True)
        if not candidate.is_file() or not candidate.is_relative_to(source):
            raise ValueError("Tệp không hợp lệ")
        if human_file_type(candidate) is None:
            raise ValueError("Định dạng không được hỗ trợ")
        return candidate, relative

    def _image_cache_path(
        self,
        media_path: Path,
        relative: str,
        *,
        variant: str,
        size: int,
        quality: int,
    ) -> Path:
        config = self.server.album_config
        stat = media_path.stat()
        fingerprint = "\0".join(
            [
                relative,
                str(stat.st_mtime_ns),
                str(stat.st_size),
                variant,
                str(size),
                str(quality),
                "v1",
            ]
        )
        digest = hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()
        return config.cache / digest[:2] / f"{digest}.jpg"

    def _create_video_thumbnail(self, source: Path, destination: Path) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            raise FileNotFoundError("ffmpeg chưa được cài")
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(
            f".{destination.stem}.{os.getpid()}.{threading.get_ident()}.tmp.jpg"
        )
        size = self.server.album_config.thumbnail_size
        try:
            subprocess.run(
                [
                    ffmpeg,
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-ss",
                    "1",
                    "-i",
                    str(source),
                    "-frames:v",
                    "1",
                    "-vf",
                    f"scale={size}:{size}:force_original_aspect_ratio=decrease",
                    "-q:v",
                    "5",
                    "-y",
                    str(temporary),
                ],
                check=True,
                timeout=30,
            )
            temporary.replace(destination)
        finally:
            temporary.unlink(missing_ok=True)

    def _serve_thumbnail(self, token: str, *, send_body: bool) -> None:
        media_path, relative = self._resolve_media(token)
        config = self.server.album_config
        destination = self._image_cache_path(
            media_path,
            relative,
            variant="thumbnail",
            size=config.thumbnail_size,
            quality=config.thumbnail_quality,
        )
        if not destination.exists():
            try:
                if human_file_type(media_path) == "image":
                    create_thumbnail(
                        media_path,
                        destination,
                        config.thumbnail_size,
                        config.thumbnail_quality,
                    )
                else:
                    self._create_video_thumbnail(media_path, destination)
            except (OSError, subprocess.SubprocessError, ValueError):
                self._send_error(HTTPStatus.NOT_FOUND, "Không tạo được ảnh xem trước")
                return
        self._serve_file(
            destination,
            content_type="image/jpeg",
            cache_control="private, max-age=86400",
            allow_ranges=False,
            send_body=send_body,
        )

    def _serve_preview(self, token: str, *, send_body: bool) -> None:
        media_path, relative = self._resolve_media(token)
        if human_file_type(media_path) == "video":
            self._serve_media(token, send_body=send_body)
            return

        config = self.server.album_config
        destination = self._image_cache_path(
            media_path,
            relative,
            variant="preview",
            size=config.preview_size,
            quality=config.preview_quality,
        )
        if not destination.exists():
            try:
                create_thumbnail(
                    media_path,
                    destination,
                    config.preview_size,
                    config.preview_quality,
                )
            except (OSError, ValueError):
                self._send_error(HTTPStatus.NOT_FOUND, "Không tạo được bản xem trước")
                return
        self._serve_file(
            destination,
            content_type="image/jpeg",
            cache_control="private, max-age=86400",
            allow_ranges=False,
            send_body=send_body,
        )

    def _serve_media(self, token: str, *, send_body: bool) -> None:
        media_path, _ = self._resolve_media(token)
        content_type = mimetypes.guess_type(media_path.name)[0] or "application/octet-stream"
        self._serve_file(
            media_path,
            content_type=content_type,
            cache_control="private, max-age=3600",
            allow_ranges=True,
            send_body=send_body,
        )

    def _serve_static(self, file_name: str, *, send_body: bool) -> None:
        path = self.server.album_config.static / file_name
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self._serve_file(
            path,
            content_type=content_type,
            cache_control="private, max-age=300",
            allow_ranges=False,
            send_body=send_body,
        )

    def _serve_file(
        self,
        path: Path,
        *,
        content_type: str,
        cache_control: str,
        allow_ranges: bool,
        send_body: bool,
    ) -> None:
        stat = path.stat()
        etag = f'"{stat.st_mtime_ns:x}-{stat.st_size:x}"'
        if self.headers.get("If-None-Match") == etag:
            self.send_response(HTTPStatus.NOT_MODIFIED)
            self._send_common_headers(cache_control=cache_control)
            self.send_header("ETag", etag)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        byte_range = None
        if allow_ranges:
            try:
                byte_range = parse_byte_range(self.headers.get("Range"), stat.st_size)
            except (TypeError, ValueError):
                self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                self._send_common_headers(cache_control=cache_control)
                self.send_header("Content-Range", f"bytes */{stat.st_size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return

        if byte_range is None:
            start, end = 0, stat.st_size - 1
            self.send_response(HTTPStatus.OK)
        else:
            start, end = byte_range
            self.send_response(HTTPStatus.PARTIAL_CONTENT)
            self.send_header("Content-Range", f"bytes {start}-{end}/{stat.st_size}")

        content_length = max(0, end - start + 1)
        self._send_common_headers(cache_control=cache_control)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(content_length))
        self.send_header("ETag", etag)
        if allow_ranges:
            self.send_header("Accept-Ranges", "bytes")
        self.end_headers()

        if not send_body or content_length == 0:
            return
        with path.open("rb") as source:
            source.seek(start)
            self._copy_range(source, content_length)

    def _copy_range(self, source: BinaryIO, length: int) -> None:
        remaining = length
        while remaining > 0:
            chunk = source.read(min(1024 * 1024, remaining))
            if not chunk:
                break
            self.wfile.write(chunk)
            remaining -= len(chunk)

    def _send_json(self, payload: object, *, send_body: bool) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self._send_common_headers(cache_control="private, no-store")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if send_body:
            self.wfile.write(body)

    def _send_error(self, status: HTTPStatus, message: str) -> None:
        body = json.dumps({"error": message}, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_common_headers(cache_control="no-store")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_common_headers(self, *, cache_control: str) -> None:
        self.send_header("Cache-Control", cache_control)
        allowed_origin = self._allowed_cors_origin()
        if allowed_origin is not None:
            self.send_header("Access-Control-Allow-Origin", allowed_origin)
            if allowed_origin != "*":
                self.send_header("Access-Control-Allow-Credentials", "true")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header(
                "Access-Control-Expose-Headers",
                "Accept-Ranges, Content-Length, Content-Range, ETag",
            )
            self.send_header("Vary", "Origin")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
            "script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; "
            "form-action 'self'; frame-ancestors 'none'",
        )

    def _allowed_cors_origin(self) -> str | None:
        origin = self.headers.get("Origin", "").strip()
        if not origin:
            return None
        configured = self.server.album_config.cors_origins
        if "*" in configured:
            return "*"
        return origin if origin in configured else None

    def log_message(self, format_string: str, *args: object) -> None:
        print(f"{self.address_string()} - {format_string % args}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Serve a private read-only album")
    parser.add_argument(
        "source",
        nargs="?",
        type=Path,
        default=Path(os.environ.get("ALBUM_DIR", ".")),
        help="Album directory (default: ALBUM_DIR or current directory)",
    )
    parser.add_argument("--host", default=os.environ.get("ALBUM_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("ALBUM_PORT", "8000")))
    parser.add_argument(
        "--thumbnail-size",
        type=int,
        default=int(os.environ.get("ALBUM_THUMBNAIL_SIZE", "640")),
    )
    parser.add_argument(
        "--thumbnail-quality",
        type=int,
        default=int(os.environ.get("ALBUM_THUMBNAIL_QUALITY", "78")),
    )
    parser.add_argument(
        "--page-size",
        type=int,
        default=int(os.environ.get("ALBUM_PAGE_SIZE", "80")),
    )
    parser.add_argument(
        "--metadata-file",
        type=Path,
        default=Path(os.environ.get("ALBUM_METADATA_FILE", METADATA_FILE_NAME)),
        help="ExifTool metadata JSON (default: album-metadata.json inside the album)",
    )
    parser.add_argument(
        "--preview-size",
        type=int,
        default=int(os.environ.get("ALBUM_PREVIEW_SIZE", "2048")),
    )
    parser.add_argument(
        "--preview-quality",
        type=int,
        default=int(os.environ.get("ALBUM_PREVIEW_QUALITY", "84")),
    )
    parser.add_argument(
        "--auth-file",
        type=Path,
        default=Path(os.environ.get("ALBUM_AUTH_FILE", "~/.config/my-album/auth.json")),
        help="Authentication file created by setup_auth.py",
    )
    parser.add_argument(
        "--require-auth",
        action="store_true",
        default=os.environ.get("ALBUM_REQUIRE_AUTH", "").casefold() in {"1", "true", "yes"},
        help="Refuse to start when the authentication file is missing",
    )
    parser.add_argument(
        "--insecure-cookie",
        action="store_true",
        help="Allow the session cookie over HTTP for local testing only",
    )
    parser.add_argument(
        "--no-auth",
        action="store_true",
        help="Disable authentication even when the default auth file exists",
    )
    parser.add_argument(
        "--cors-origin",
        action="append",
        default=[],
        help="Allow read-only browser access from this exact origin; repeat as needed",
    )
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> AlbumConfig:
    source = args.source.expanduser().resolve()
    if not source.is_dir():
        raise ValueError(f"Album directory does not exist: {source}")
    if not 1 <= args.thumbnail_quality <= 95:
        raise ValueError("thumbnail quality must be between 1 and 95")
    if not 160 <= args.thumbnail_size <= 2560:
        raise ValueError("thumbnail size must be between 160 and 2560")
    if not 640 <= args.preview_size <= 8192:
        raise ValueError("preview size must be between 640 and 8192")
    if not 1 <= args.preview_quality <= 95:
        raise ValueError("preview quality must be between 1 and 95")
    if not 1 <= args.page_size <= 200:
        raise ValueError("page size must be between 1 and 200")
    if not 1 <= args.port <= 65535:
        raise ValueError("port must be between 1 and 65535")

    cache = Path(os.environ.get("ALBUM_CACHE_DIR", source / ".my-album-cache"))
    cache = cache.expanduser().resolve()
    cache.mkdir(parents=True, exist_ok=True)
    metadata = args.metadata_file.expanduser()
    if not metadata.is_absolute():
        metadata = source / metadata
    metadata = metadata.resolve()
    if metadata.exists() and not metadata.is_file():
        raise ValueError(f"metadata file is not a file: {metadata}")
    static = Path(__file__).with_name("album_static").resolve()
    auth_path = args.auth_file.expanduser().resolve()
    auth = None if args.no_auth else (load_auth_config(auth_path) if auth_path.is_file() else None)
    if args.require_auth and auth is None:
        raise ValueError(
            f"Authentication is required but the auth file does not exist: {auth_path}"
        )
    return AlbumConfig(
        source=source,
        cache=cache,
        metadata=metadata,
        static=static,
        host=args.host,
        port=args.port,
        thumbnail_size=args.thumbnail_size,
        thumbnail_quality=args.thumbnail_quality,
        preview_size=args.preview_size,
        preview_quality=args.preview_quality,
        page_size=args.page_size,
        auth=auth,
        secure_cookie=not args.insecure_cookie,
        cors_origins=tuple(
            dict.fromkeys(
                origin.strip()
                for origin in [
                    *args.cors_origin,
                    *os.environ.get("ALBUM_CORS_ORIGINS", "").split(","),
                ]
                if origin.strip()
            )
        ),
    )


def main() -> int:
    args = parse_args()
    try:
        config = build_config(args)
    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2

    try:
        server = AlbumHTTPServer((config.host, config.port), config)
    except OSError as error:
        print(
            f"Error: cannot listen on {config.host}:{config.port} ({error}). "
            "Stop the old album server and try again.",
            file=sys.stderr,
        )
        return 2
    print(f"Album:  {config.source}")
    print(f"Local:  http://{config.host}:{config.port}")
    print(f"Thumbs: {config.thumbnail_size}px, quality {config.thumbnail_quality}")
    print(f"Views:  {config.preview_size}px, quality {config.preview_quality}")
    print(f"Meta:   {config.metadata if config.metadata.is_file() else 'not found'}")
    print(f"Auth:   {config.auth.email if config.auth else 'disabled (local testing)'}")
    print(f"CORS:   {', '.join(config.cors_origins) if config.cors_origins else 'disabled'}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
