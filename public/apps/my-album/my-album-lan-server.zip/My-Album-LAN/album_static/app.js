"use strict";

const grid = document.querySelector("#album-grid");
const emptyState = document.querySelector("#empty-state");
const retryButton = document.querySelector("#retry-button");
const resultCount = document.querySelector("#result-count");
const loadStatus = document.querySelector("#load-status");
const searchInput = document.querySelector("#search-input");
const sortSelect = document.querySelector("#sort-select");
const sizeSlider = document.querySelector("#size-slider");
const refreshButton = document.querySelector("#refresh-button");
const accountLabel = document.querySelector("#account-label");
const logoutLink = document.querySelector("#logout-link");
const sentinel = document.querySelector("#load-sentinel");

const viewer = document.querySelector("#viewer");
const viewerStage = document.querySelector("#viewer-stage");
const viewerTitle = document.querySelector("#viewer-title");
const viewerMeta = document.querySelector("#viewer-meta");
const downloadLink = document.querySelector("#download-link");
const closeViewerButton = document.querySelector("#close-viewer");
const previousButton = document.querySelector("#previous-item");
const nextButton = document.querySelector("#next-item");

const state = {
  items: [],
  total: 0,
  hasMore: true,
  loading: false,
  filter: "all",
  sort: "newest",
  search: "",
  activeIndex: -1,
  requestVersion: 0,
};

const numberFormatter = new Intl.NumberFormat("vi-VN");
const dateFormatter = new Intl.DateTimeFormat("vi-VN", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
});

function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const unitIndex = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** unitIndex;
  return `${value >= 10 || unitIndex === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[unitIndex]}`;
}

function formatDate(timestamp) {
  return dateFormatter.format(new Date(timestamp * 1000));
}

function folderLabel(folder) {
  return folder === "." ? "Thư mục gốc" : folder;
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    credentials: "same-origin",
  });
  const contentType = response.headers.get("content-type") || "";
  if (response.status === 401) {
    window.location.assign("/login");
    throw new Error("Phiên đăng nhập đã hết hạn");
  }
  if (!response.ok || !contentType.includes("application/json")) {
    throw new Error(response.ok ? "Phản hồi không hợp lệ" : `Lỗi ${response.status}`);
  }
  const payload = await response.json();
  if (payload.error) throw new Error(payload.error);
  return payload;
}

function updateSummary() {
  if (state.loading && state.items.length === 0) {
    resultCount.textContent = "Đang tải album";
  } else {
    resultCount.textContent = `${numberFormatter.format(state.items.length)} / ${numberFormatter.format(state.total)} mục`;
  }
  emptyState.hidden = state.loading || state.items.length > 0 || state.total > 0;
}

function createAlbumItem(item) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "album-item";
  button.dataset.id = item.id;
  button.dataset.type = item.type;
  button.setAttribute("aria-label", `Mở ${item.fileName}`);

  const media = document.createElement("span");
  media.className = "album-item-media";

  const image = document.createElement("img");
  image.src = item.thumbnail;
  image.alt = "";
  image.loading = "lazy";
  image.decoding = "async";
  image.addEventListener("error", () => button.classList.add("no-thumbnail"), { once: true });

  const fallback = document.createElement("span");
  fallback.className = "media-fallback";
  fallback.textContent = item.extension || item.type;

  media.append(image, fallback);

  if (item.type === "video") {
    const badge = document.createElement("span");
    badge.className = "type-badge";
    badge.textContent = "Video";
    media.append(badge);
  }

  const copy = document.createElement("span");
  copy.className = "album-item-copy";

  const title = document.createElement("span");
  title.className = "album-item-title";
  title.textContent = item.name;
  title.title = item.fileName;

  const detail = document.createElement("span");
  detail.className = "album-item-detail";
  detail.textContent = `${folderLabel(item.folder)} · ${formatDate(item.modified)}`;
  detail.title = detail.textContent;

  copy.append(title, detail);
  button.append(media, copy);
  return button;
}

function appendItems(items) {
  const fragment = document.createDocumentFragment();
  for (const item of items) fragment.append(createAlbumItem(item));
  grid.append(fragment);
}

function buildItemsUrl({ offset, force }) {
  const parameters = new URLSearchParams({
    offset: String(offset),
    limit: "80",
    type: state.filter,
    sort: state.sort,
  });
  if (state.search) parameters.set("q", state.search);
  if (force) parameters.set("refresh", "1");
  return `/api/items?${parameters}`;
}

async function loadMore({ force = false, reset = false } = {}) {
  if (reset) {
    state.requestVersion += 1;
    state.items = [];
    state.total = 0;
    state.hasMore = true;
    state.activeIndex = -1;
    grid.replaceChildren();
    retryButton.hidden = true;
  }

  if (state.loading && !reset) return false;
  if (!state.hasMore && !reset) return false;

  const version = state.requestVersion;
  const offset = state.items.length;
  state.loading = true;
  loadStatus.textContent = "Đang tải";
  refreshButton.disabled = true;
  updateSummary();

  try {
    const payload = await fetchJson(buildItemsUrl({ offset, force }));
    if (version !== state.requestVersion) return false;
    state.items.push(...payload.items);
    state.total = payload.total;
    state.hasMore = payload.hasMore;
    appendItems(payload.items);
    loadStatus.textContent = state.hasMore ? "Cuộn để tải thêm" : "Đã tải hết";
    retryButton.hidden = true;
    return true;
  } catch (error) {
    if (version === state.requestVersion) {
      loadStatus.textContent = error instanceof Error ? error.message : "Không tải được album";
      retryButton.hidden = false;
    }
    return false;
  } finally {
    if (version === state.requestVersion) {
      state.loading = false;
      refreshButton.disabled = false;
      updateSummary();
    }
  }
}

async function reload({ force = false } = {}) {
  await loadMore({ force, reset: true });
}

function describeItem(item) {
  return [folderLabel(item.folder), item.extension.toUpperCase(), formatBytes(item.bytes), formatDate(item.modified)].join(" · ");
}

function stopViewerMedia() {
  const media = viewerStage.querySelector("video");
  if (media) {
    media.pause();
    media.removeAttribute("src");
    media.load();
  }
  viewerStage.replaceChildren();
}

function renderViewer() {
  const item = state.items[state.activeIndex];
  if (!item) return;

  stopViewerMedia();
  viewerTitle.textContent = item.fileName;
  viewerMeta.textContent = describeItem(item);
  downloadLink.href = item.media;
  downloadLink.download = item.fileName;

  const loading = document.createElement("p");
  loading.className = "viewer-message";
  loading.textContent = "Đang tải";
  viewerStage.append(loading);

  let media;
  if (item.type === "video") {
    media = document.createElement("video");
    media.controls = true;
    media.autoplay = true;
    media.playsInline = true;
    media.preload = "metadata";
    media.src = item.view || item.media;
    media.addEventListener("loadedmetadata", () => loading.remove(), { once: true });
  } else {
    media = document.createElement("img");
    media.alt = item.name;
    media.src = item.view || item.media;
    media.decoding = "async";
    media.addEventListener("load", () => loading.remove(), { once: true });
  }

  media.addEventListener(
    "error",
    () => {
      loading.textContent = "Không thể mở tệp này trong trình duyệt";
    },
    { once: true },
  );
  viewerStage.append(media);

  previousButton.disabled = state.activeIndex <= 0;
  nextButton.disabled = state.activeIndex >= state.items.length - 1 && !state.hasMore;
}

function openViewer(index) {
  if (!state.items[index]) return;
  state.activeIndex = index;
  renderViewer();
  if (!viewer.open) viewer.showModal();
}

function closeViewer() {
  if (viewer.open) viewer.close();
}

async function showNextItem() {
  if (state.activeIndex < state.items.length - 1) {
    state.activeIndex += 1;
    renderViewer();
    return;
  }
  if (!state.hasMore) return;
  const loaded = await loadMore();
  if (loaded && state.activeIndex < state.items.length - 1) {
    state.activeIndex += 1;
    renderViewer();
  }
}

function showPreviousItem() {
  if (state.activeIndex <= 0) return;
  state.activeIndex -= 1;
  renderViewer();
}

async function loadSession() {
  try {
    const session = await fetchJson("/api/session");
    accountLabel.textContent = session.email;
    logoutLink.hidden = !session.authenticated;
  } catch {
    accountLabel.textContent = "Phiên không xác định";
  }
}

let searchTimer = 0;
searchInput.addEventListener("input", () => {
  window.clearTimeout(searchTimer);
  searchTimer = window.setTimeout(() => {
    state.search = searchInput.value.trim();
    reload();
  }, 280);
});

document.querySelectorAll("[data-filter]").forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;
    if (!filter || state.filter === filter) return;
    state.filter = filter;
    document.querySelectorAll("[data-filter]").forEach((candidate) => {
      candidate.setAttribute("aria-pressed", String(candidate === button));
    });
    reload();
  });
});

sortSelect.addEventListener("change", () => {
  state.sort = sortSelect.value;
  reload();
});

sizeSlider.addEventListener("input", () => {
  document.documentElement.style.setProperty("--tile-min", `${sizeSlider.value}px`);
});

refreshButton.addEventListener("click", () => reload({ force: true }));
retryButton.addEventListener("click", () => loadMore({ reset: state.items.length === 0 }));

grid.addEventListener("click", (event) => {
  const itemElement = event.target.closest(".album-item");
  if (!itemElement) return;
  const index = state.items.findIndex((item) => item.id === itemElement.dataset.id);
  openViewer(index);
});

closeViewerButton.addEventListener("click", closeViewer);
previousButton.addEventListener("click", showPreviousItem);
nextButton.addEventListener("click", showNextItem);
viewer.addEventListener("close", stopViewerMedia);
viewer.addEventListener("click", (event) => {
  if (event.target === viewer) closeViewer();
});

document.addEventListener("keydown", (event) => {
  if (!viewer.open) return;
  if (event.key === "ArrowLeft") showPreviousItem();
  if (event.key === "ArrowRight") showNextItem();
});

const observer = new IntersectionObserver(
  (entries) => {
    if (entries.some((entry) => entry.isIntersecting)) loadMore();
  },
  { rootMargin: "600px 0px" },
);
observer.observe(sentinel);

loadSession();
reload();
