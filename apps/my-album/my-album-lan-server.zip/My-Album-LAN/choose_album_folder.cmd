@echo off
call "%~dp0start_my_album.cmd" --choose
