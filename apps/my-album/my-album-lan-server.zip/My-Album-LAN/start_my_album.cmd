@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

set "PYTHON_CMD=py -3"
where py >nul 2>&1
if errorlevel 1 (
  where python >nul 2>&1
  if errorlevel 1 (
    echo Không tìm thấy Python 3.
    echo Hãy cài Python từ https://www.python.org/downloads/windows/
    echo Khi cài, nhớ chọn Add Python to PATH.
    pause
    exit /b 2
  )
  set "PYTHON_CMD=python"
)

if not exist ".venv\Scripts\python.exe" (
  echo Đang chuẩn bị My Album cho lần chạy đầu tiên...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto :failed
)

".venv\Scripts\python.exe" -c "import PIL; import pillow_heif" >nul 2>&1
if errorlevel 1 (
  echo Đang cài thư viện xử lý ảnh. Việc này chỉ thực hiện một lần...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 goto :failed
)

".venv\Scripts\python.exe" album_launcher.py %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
  echo My Album đã dừng.
) else (
  echo My Album chưa thể khởi động. Xem thông báo phía trên.
)
pause
exit /b %EXIT_CODE%

:failed
echo.
echo Cài đặt chưa hoàn tất. Kiểm tra kết nối Internet rồi chạy lại file này.
pause
exit /b 1
