MY ALBUM - CHẠY TRÊN MÁY WINDOWS

Lần đầu:
1. Giải nén toàn bộ gói này.
2. Dừng cửa sổ server cũ đang dùng cổng 8000 bằng Ctrl+C.
3. Nhấp đúp start_my_album.cmd.
4. Chọn thư mục lớn đang chứa album.
5. Nếu Windows Firewall hỏi, chọn Allow access cho Private networks.

Những lần sau chỉ cần nhấp đúp start_my_album.cmd. Chương trình sẽ nhớ thư mục.

Đổi thư mục album:
- Nhấp đúp choose_album_folder.cmd.

Trên thiết bị xem album:
- Mở https://vuducan.qzz.io/apps/my-album/
- Nhập IP của máy Windows và cổng 8000.

Trên iPhone/iPad:
- Safari có thể chặn trang HTTPS đọc trực tiếp server HTTP trong mạng LAN.
- Khi My Album báo lỗi, bấm "Mở album trên iPhone".
- Safari sẽ chuyển tới http://IP-MAY-WINDOWS:8000 và giữ nguyên giao diện My Album.
- Cho phép Safari truy cập Mạng cục bộ trong Cài đặt của iPhone.

Kiểm tra server mới:
- Mở http://IP-MAY-WINDOWS:8000/healthz.
- Kết quả đúng là JSON có trạng thái "ok".
- Trên My Album, trạng thái kết nối phải là "LAN API", không phải "Thư mục LAN".

Lưu ý:
- Giữ cửa sổ My Album mở trong lúc xem.
- Không mở port 8000 trên router.
- Server chỉ cho đọc. Ảnh và video gốc không bị thay đổi.
- Thumbnail và ảnh xem trước được lưu trong .my-album-cache của thư mục album.
