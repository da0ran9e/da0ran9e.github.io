MY ALBUM - CHẠY TRÊN MÁY WINDOWS

Lần đầu:
1. Giải nén toàn bộ gói này.
2. Dừng cửa sổ server cũ đang dùng cổng 8000 bằng Ctrl+C.
3. Nhấp đúp start_my_album.cmd.
4. Chọn thư mục lớn đang chứa album.
5. Nếu Windows Firewall hỏi, chọn Allow access cho Private networks.

Những lần sau chỉ cần nhấp đúp start_my_album.cmd. Chương trình sẽ nhớ thư mục.

Đổi thư mục album:
- Nhấp đúp choose_album_folder.cmd.

Trên thiết bị xem album:
- Mở https://vuducan.qzz.io/apps/my-album/
- My Album sẽ tự kết nối tới https://photos.vuducan.qzz.io/.
- Nếu được yêu cầu, mở nút "Kho ảnh" và đăng nhập Cloudflare Access, sau đó quay lại bấm "Thử lại".

Cloudflare Tunnel:
- Tunnel photos.vuducan.qzz.io phải trỏ tới http://localhost:8000 trên máy Windows.
- Giữ cloudflared và cửa sổ My Album cùng hoạt động trong lúc xem.
- Không cần mở cổng 8000 trên router và không cần nhập IP LAN trong ứng dụng.

Kiểm tra server mới:
- Mở https://photos.vuducan.qzz.io/healthz sau khi đăng nhập.
- Kết quả đúng là JSON có trạng thái "ok" và apiVersion 5.
- Trên My Album, trạng thái kết nối phải là "Cloud API", không phải "Thư mục Cloud".

Dòng thời gian và bộ lọc:
- Album chia ảnh và video theo từng ngày dựa trên thời gian chỉnh sửa của tệp.
- Nút Lọc cho phép thu hẹp theo thư mục, năm, tháng và ngày.
- Việc đọc mốc thời gian không làm thay đổi hoặc mở nội dung ảnh gốc.

Lưu ý:
- Giữ cửa sổ My Album mở trong lúc xem.
- Không mở port 8000 trên router.
- Server chỉ cho đọc. Ảnh và video gốc không bị thay đổi.
- Thumbnail và ảnh xem trước được lưu trong .my-album-cache của thư mục album.
