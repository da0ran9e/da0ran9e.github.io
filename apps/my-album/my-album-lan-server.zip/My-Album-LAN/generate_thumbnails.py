#!/usr/bin/env python3
"""Create incremental thumbnails for an image directory.

The output directory mirrors the source directory. Existing thumbnails are
left untouched unless --force is supplied, so repeated scans only process new
images.
"""

from __future__ import annotations

import argparse
import os
import sys
import threading
import time
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageOps, UnidentifiedImageError

try:
    import pillow_heif

    pillow_heif.register_heif_opener()
except ImportError:
    pillow_heif = None


SUPPORTED_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".gif",
    ".bmp",
    ".tif",
    ".tiff",
    ".heic",
    ".heif",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create JPEG thumbnails and skip ones that already exist."
    )
    parser.add_argument("source", type=Path, help="Directory containing images")
    parser.add_argument(
        "--output",
        type=Path,
        help="Thumbnail directory (default: SOURCE/_thumbnails)",
    )
    parser.add_argument(
        "--size",
        type=int,
        default=320,
        help="Maximum thumbnail width/height in pixels (default: 320)",
    )
    parser.add_argument(
        "--quality",
        type=int,
        default=82,
        help="JPEG quality from 1 to 95 (default: 82)",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Keep scanning and create thumbnails for newly added images",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=10.0,
        help="Seconds between scans in watch mode (default: 10)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Recreate thumbnails even when they already exist",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> tuple[Path, Path]:
    source = args.source.expanduser().resolve()
    output = (args.output or source / "_thumbnails").expanduser().resolve()

    if not source.is_dir():
        raise ValueError(f"Source directory does not exist: {source}")
    if args.size < 1:
        raise ValueError("--size must be at least 1")
    if not 1 <= args.quality <= 95:
        raise ValueError("--quality must be between 1 and 95")
    if args.interval <= 0:
        raise ValueError("--interval must be greater than 0")
    if output == source:
        raise ValueError("--output must not be the same directory as SOURCE")

    output.mkdir(parents=True, exist_ok=True)
    return source, output


def iter_images(source: Path, output: Path) -> Iterable[Path]:
    """Yield supported source images without descending into output."""
    for path in source.rglob("*"):
        if output == path or output in path.parents:
            continue
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS:
            yield path


def thumbnail_path(image_path: Path, source: Path, output: Path) -> Path:
    relative = image_path.relative_to(source)
    # Keep the original extension in the name to avoid collisions such as
    # photo.jpg and photo.heic in the same directory.
    return output / relative.parent / f"{relative.name}.jpg"


def flatten_transparency(image: Image.Image) -> Image.Image:
    if image.mode in {"RGBA", "LA"} or (
        image.mode == "P" and "transparency" in image.info
    ):
        rgba = image.convert("RGBA")
        background = Image.new("RGB", rgba.size, "white")
        background.paste(rgba, mask=rgba.getchannel("A"))
        return background
    return image.convert("RGB")


def create_thumbnail(
    image_path: Path,
    destination: Path,
    size: int,
    quality: int,
) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(
        f".{destination.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )

    try:
        with Image.open(image_path) as opened:
            image = ImageOps.exif_transpose(opened)
            image.seek(0)
            image.thumbnail((size, size), Image.Resampling.LANCZOS)
            rgb = flatten_transparency(image)
            rgb.save(
                temporary,
                format="JPEG",
                quality=quality,
                optimize=True,
                progressive=True,
            )
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def scan_once(
    source: Path,
    output: Path,
    size: int,
    quality: int,
    force: bool,
) -> tuple[int, int, int]:
    created = 0
    skipped = 0
    failed = 0

    for image_path in iter_images(source, output):
        destination = thumbnail_path(image_path, source, output)
        if destination.exists() and not force:
            skipped += 1
            continue

        try:
            create_thumbnail(image_path, destination, size, quality)
            created += 1
            print(f"CREATED  {destination.relative_to(output)}", flush=True)
        except (OSError, ValueError, UnidentifiedImageError) as error:
            failed += 1
            print(f"FAILED   {image_path}: {error}", file=sys.stderr, flush=True)

    return created, skipped, failed


def main() -> int:
    args = parse_args()
    try:
        source, output = validate_args(args)
    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2

    if pillow_heif is None:
        print(
            "Note: pillow-heif is not installed; HEIC/HEIF files may fail. "
            "Install dependencies with: pip install -r requirements.txt",
            file=sys.stderr,
        )

    print(f"Source:     {source}")
    print(f"Thumbnails: {output}")

    while True:
        created, skipped, failed = scan_once(
            source=source,
            output=output,
            size=args.size,
            quality=args.quality,
            force=args.force,
        )
        print(
            f"Scan complete: {created} created, {skipped} skipped, "
            f"{failed} failed",
            flush=True,
        )

        if not args.watch:
            return 1 if failed else 0

        # --force is useful for one-off rebuilds, but watch mode should not
        # recreate every thumbnail on every scan.
        args.force = False
        try:
            time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nStopped.")
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
