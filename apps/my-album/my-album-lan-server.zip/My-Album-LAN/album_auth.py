"""Authentication helpers for the private album server."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from dataclasses import dataclass
from pathlib import Path


SCRYPT_N = 2**15
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_LENGTH = 32
SCRYPT_MAX_MEMORY = 64 * 1024 * 1024


def _encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def _decode(value: str) -> bytes:
    return base64.urlsafe_b64decode((value + "=" * (-len(value) % 4)).encode("ascii"))


def hash_password(password: str) -> str:
    if len(password) < 12:
        raise ValueError("Password must contain at least 12 characters")
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
        maxmem=SCRYPT_MAX_MEMORY,
        dklen=SCRYPT_LENGTH,
    )
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_encode(salt)}${_encode(digest)}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, n_text, r_text, p_text, salt_text, digest_text = stored_hash.split("$", 5)
        if algorithm != "scrypt":
            return False
        n, r, p = int(n_text), int(r_text), int(p_text)
        salt = _decode(salt_text)
        expected = _decode(digest_text)
        if n > SCRYPT_N or r > 16 or p > 4 or len(expected) != SCRYPT_LENGTH:
            return False
        actual = hashlib.scrypt(
            password.encode("utf-8"),
            salt=salt,
            n=n,
            r=r,
            p=p,
            maxmem=SCRYPT_MAX_MEMORY,
            dklen=len(expected),
        )
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


@dataclass(frozen=True)
class AuthConfig:
    email: str
    password_hash: str
    session_secret: bytes
    session_hours: int = 168
    cookie_name: str = "my_album_session"


def load_auth_config(path: Path) -> AuthConfig:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        email = str(payload["email"]).strip().casefold()
        password_hash = str(payload["password_hash"])
        session_secret = _decode(str(payload["session_secret"]))
        session_hours = int(payload.get("session_hours", 168))
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError(f"Invalid auth file: {path}") from error

    if "@" not in email or not email:
        raise ValueError("Auth email is invalid")
    if not password_hash.startswith("scrypt$"):
        raise ValueError("Auth password hash is invalid")
    if len(session_secret) < 32:
        raise ValueError("Auth session secret is too short")
    if not 1 <= session_hours <= 24 * 365:
        raise ValueError("Auth session_hours must be between 1 and 8760")
    return AuthConfig(
        email=email,
        password_hash=password_hash,
        session_secret=session_secret,
        session_hours=session_hours,
    )


def write_auth_config(path: Path, email: str, password: str, *, force: bool = False) -> None:
    normalized_email = email.strip().casefold()
    if "@" not in normalized_email:
        raise ValueError("Email address is invalid")

    payload = {
        "email": normalized_email,
        "password_hash": hash_password(password),
        "session_secret": _encode(secrets.token_bytes(48)),
        "session_hours": 168,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT
    flags |= os.O_TRUNC if force else os.O_EXCL
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError as error:
        raise ValueError(f"Auth file already exists: {path}") from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as output:
        json.dump(payload, output, ensure_ascii=True, indent=2)
        output.write("\n")
    path.chmod(0o600)


def create_session_token(auth: AuthConfig, now: int | None = None) -> str:
    issued_at = int(time.time()) if now is None else now
    payload = {
        "email": auth.email,
        "exp": issued_at + auth.session_hours * 3600,
        "nonce": _encode(secrets.token_bytes(12)),
    }
    encoded_payload = _encode(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    )
    signature = hmac.new(
        auth.session_secret,
        encoded_payload.encode("ascii"),
        hashlib.sha256,
    ).digest()
    return f"{encoded_payload}.{_encode(signature)}"


def verify_session_token(auth: AuthConfig, token: str, now: int | None = None) -> bool:
    try:
        encoded_payload, encoded_signature = token.split(".", 1)
        supplied_signature = _decode(encoded_signature)
        expected_signature = hmac.new(
            auth.session_secret,
            encoded_payload.encode("ascii"),
            hashlib.sha256,
        ).digest()
        if not hmac.compare_digest(supplied_signature, expected_signature):
            return False
        payload = json.loads(_decode(encoded_payload).decode("utf-8"))
        current_time = int(time.time()) if now is None else now
        return (
            hmac.compare_digest(str(payload.get("email", "")), auth.email)
            and current_time < int(payload.get("exp", 0))
        )
    except (ValueError, TypeError, UnicodeError, json.JSONDecodeError):
        return False


class LoginRateLimiter:
    def __init__(self, maximum_attempts: int = 5, window_seconds: int = 900) -> None:
        self.maximum_attempts = maximum_attempts
        self.window_seconds = window_seconds
        self._attempts: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allowed(self, client_key: str, now: float | None = None) -> bool:
        current_time = time.monotonic() if now is None else now
        with self._lock:
            recent = [
                value
                for value in self._attempts.get(client_key, [])
                if current_time - value < self.window_seconds
            ]
            self._attempts[client_key] = recent
            return len(recent) < self.maximum_attempts

    def record_failure(self, client_key: str, now: float | None = None) -> None:
        current_time = time.monotonic() if now is None else now
        with self._lock:
            self._attempts.setdefault(client_key, []).append(current_time)

    def clear(self, client_key: str) -> None:
        with self._lock:
            self._attempts.pop(client_key, None)
