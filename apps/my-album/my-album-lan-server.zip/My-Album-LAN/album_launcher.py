#!/usr/bin/env python3
"""One-click Windows launcher for the LAN album server."""

from __future__ import annotations

import argparse
import json
import socket
import sys
import threading
import webbrowser
from pathlib import Path

import album_server


APP_URL = "https://vuducan.qzz.io/apps/my-album/"
CONFIG_PATH = Path(__file__).with_name("album-lan-config.json")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Start My Album on the local network")
    parser.add_argument("source", nargs="?", type=Path)
    parser.add_argument("--choose", action="store_true", help="Choose a different album folder")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--no-open", action="store_true")
    return parser.parse_args()


def load_saved_source() -> Path | None:
    try:
        payload = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        source = Path(payload["source"]).expanduser().resolve()
        return source if source.is_dir() else None
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return None


def choose_source() -> Path | None:
    selected = ""
    try:
        from tkinter import Tk, filedialog

        root = Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(title="Chọn thư mục chứa album")
        root.destroy()
    except (ImportError, RuntimeError):
        selected = input("Nhập đường dẫn thư mục album: ").strip().strip('"')

    if not selected:
        return None
    source = Path(selected).expanduser().resolve()
    return source if source.is_dir() else None


def save_source(source: Path) -> None:
    CONFIG_PATH.write_text(
        json.dumps({"source": str(source)}, ensure_ascii=True, indent=2) + "\n",
        encoding="utf-8",
    )


def detect_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
            connection.connect(("10.255.255.255", 1))
            return str(connection.getsockname()[0])
    except OSError:
        return "127.0.0.1"


def main() -> int:
    args = parse_args()
    source = args.source.expanduser().resolve() if args.source else None
    if source is not None and not source.is_dir():
        print(f"Không tìm thấy thư mục: {source}")
        return 2
    if source is None and not args.choose:
        source = load_saved_source()
    if source is None:
        source = choose_source()
    if source is None:
        print("Chưa chọn thư mục album.")
        return 2

    save_source(source)
    lan_ip = detect_lan_ip()
    print()
    print("My Album đang khởi động")
    print(f"Thư mục: {source}")
    print(f"Địa chỉ: {lan_ip}:{args.port}")
    print("Giữ cửa sổ này mở trong lúc xem album.")
    print("Nhấn Ctrl+C để dừng server.")
    print()

    if not args.no_open:
        opener = threading.Timer(1.5, webbrowser.open, args=(APP_URL,))
        opener.daemon = True
        opener.start()

    sys.argv = [
        "album_server.py",
        str(source),
        "--host",
        "0.0.0.0",
        "--port",
        str(args.port),
        "--no-auth",
        "--cors-origin",
        "https://vuducan.qzz.io",
        "--thumbnail-size",
        "480",
        "--thumbnail-quality",
        "76",
        "--preview-size",
        "1920",
        "--preview-quality",
        "82",
    ]
    return album_server.main()


if __name__ == "__main__":
    raise SystemExit(main())
