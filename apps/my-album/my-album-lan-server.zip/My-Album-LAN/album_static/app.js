(() => {
  "use strict";

  const CLOUD_ALBUM_URL = "https://photos.vuducan.qzz.io/";
  const CLOUD_ENDPOINT = Object.freeze({
    url: CLOUD_ALBUM_URL,
    label: "photos.vuducan.qzz.io",
    kind: "cloud",
  });
  const HIDDEN_ITEMS_STORAGE_KEY = "my-album-hidden-items-v1";
  const THEME_STORAGE_KEY = "my-album-theme-v1";
  const PAGE_SIZE = 80;
  const MAX_CONCURRENT_REQUESTS = 4;
  const PROBE_TIMEOUT_MS = 10000;
  const API_TIMEOUT_MS = 120000;
  const DIRECTORY_TIMEOUT_MS = 15000;
  const VIEWER_CACHE_DELAY_MS = 8000;
  const VIEWED_IMAGE_CACHE_MAX_BYTES = 512 * 1024 * 1024;
  const THUMBNAIL_CACHE_NAME = "my-album-thumbnails-v1";
  const VIEWED_IMAGE_CACHE_NAME = "my-album-viewed-images-v1";
  const CATALOG_CACHE_NAME = "my-album-catalog-v1";
  const VIEWED_IMAGE_CACHE_INDEX_KEY = "my-album-viewed-images-index-v1";
  const IMAGE_EXTENSIONS = new Set([
    "jpg", "jpeg", "png", "webp", "gif", "bmp", "tif", "tiff", "heic", "heif",
  ]);
  const VIDEO_EXTENSIONS = new Set(["mp4", "m4v", "mov", "webm", "avi", "mkv"]);
  const SKIPPED_DIRECTORIES = new Set([
    "thumbs", "_thumbnails", ".my-album-cache", "__pycache__",
  ]);

  class ApiUnavailableError extends Error {}

  const state = {
    endpoint: null,
    baseUrl: "",
    mode: null,
    items: [],
    visibleItems: [],
    total: 0,
    stats: null,
    facets: { folders: [], dates: [] },
    hasMore: false,
    filter: "all",
    view: "library",
    query: "",
    sort: "newest",
    timelineFilters: { folder: "", year: "", month: "", day: "" },
    renderedCount: 0,
    requestVersion: 0,
    isLoading: false,
    isLoadingMore: false,
    viewerIndex: -1,
    viewerLoadToken: 0,
    viewerAbortController: null,
    viewerObjectUrl: null,
    viewerCacheTimer: null,
    viewerBlob: null,
    viewerCacheUrl: null,
    hiddenIds: new Set(),
    selectedIds: new Set(),
    selectionMode: false,
    lastSelectedIndex: -1,
    isDownloading: false,
    downloadAbortController: null,
    toastTimer: null,
    isLocalServer: false,
  };

  const elements = {
    endpointLabel: document.querySelector("#endpoint-label"),
    openCloud: document.querySelector("#open-cloud"),
    themeToggle: document.querySelector("#theme-toggle"),
    searchInput: document.querySelector("#search-input"),
    navigationButtons: [...document.querySelectorAll("[data-library-nav]")],
    hiddenCount: document.querySelector("#hidden-count"),
    filterButtons: [...document.querySelectorAll("[data-filter]")],
    sortSelect: document.querySelector("#sort-select"),
    timelineFilterButton: document.querySelector("#timeline-filter-button"),
    timelineFilterCount: document.querySelector("#timeline-filter-count"),
    sizeInput: document.querySelector("#size-input"),
    connectionNotice: document.querySelector("#connection-notice"),
    noticeTitle: document.querySelector("#notice-title"),
    noticeMessage: document.querySelector("#notice-message"),
    retryButton: document.querySelector("#retry-button"),
    noticeOpenDirect: document.querySelector("#notice-open-direct"),
    albumSummary: document.querySelector("#album-summary"),
    albumTitle: document.querySelector("#album-title"),
    connectionMode: document.querySelector("#connection-mode"),
    scanStatus: document.querySelector("#scan-status"),
    scanStatusText: document.querySelector("#scan-status-text"),
    refreshButton: document.querySelector("#refresh-button"),
    selectButton: document.querySelector("#select-button"),
    mediaGrid: document.querySelector("#media-grid"),
    emptyState: document.querySelector("#empty-state"),
    emptyTitle: document.querySelector("#empty-state h2"),
    emptyCopy: document.querySelector("#empty-state p"),
    emptyConnect: document.querySelector("#empty-connect"),
    loadSentinel: document.querySelector("#load-sentinel"),
    filterDialog: document.querySelector("#filter-dialog"),
    filterForm: document.querySelector("#filter-form"),
    filterClose: document.querySelector("#filter-close"),
    filterReset: document.querySelector("#filter-reset"),
    folderFilter: document.querySelector("#folder-filter"),
    yearFilter: document.querySelector("#year-filter"),
    monthFilter: document.querySelector("#month-filter"),
    dayFilter: document.querySelector("#day-filter"),
    viewerDialog: document.querySelector("#viewer-dialog"),
    viewerShell: document.querySelector("#viewer-shell"),
    viewerName: document.querySelector("#viewer-name"),
    viewerFolder: document.querySelector("#viewer-folder"),
    viewerDetails: document.querySelector("#viewer-details"),
    viewerInfoName: document.querySelector("#viewer-info-name"),
    viewerInfoFolder: document.querySelector("#viewer-info-folder"),
    viewerInfoType: document.querySelector("#viewer-info-type"),
    viewerInfoToggle: document.querySelector("#viewer-info-toggle"),
    viewerInfoClose: document.querySelector("#viewer-info-close"),
    viewerOpenOriginal: document.querySelector("#viewer-open-original"),
    viewerClose: document.querySelector("#viewer-close"),
    viewerPrevious: document.querySelector("#viewer-previous"),
    viewerNext: document.querySelector("#viewer-next"),
    viewerStage: document.querySelector("#viewer-stage"),
    viewerCount: document.querySelector("#viewer-count"),
    viewerOfflineStatus: document.querySelector("#viewer-offline-status"),
    viewerDownload: document.querySelector("#viewer-download"),
    selectionBar: document.querySelector("#selection-bar"),
    selectionCancel: document.querySelector("#selection-cancel"),
    selectionCount: document.querySelector("#selection-count"),
    selectionProgress: document.querySelector("#selection-progress"),
    selectionProgressBar: document.querySelector("#selection-progress-bar"),
    selectAllButton: document.querySelector("#select-all-button"),
    downloadSelected: document.querySelector("#download-selected"),
    hideSelected: document.querySelector("#hide-selected"),
    restoreSelected: document.querySelector("#restore-selected"),
    toast: document.querySelector("#toast"),
    mediaCardTemplate: document.querySelector("#media-card-template"),
  };

  const numberFormatter = new Intl.NumberFormat("vi-VN");
  const textEncoder = new TextEncoder();
  const dateFormatter = new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
  const timelineDateFormatter = new Intl.DateTimeFormat("vi-VN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const monthFormatter = new Intl.DateTimeFormat("vi-VN", { month: "long" });
  const folderCollator = new Intl.Collator("vi", { numeric: true, sensitivity: "base" });
  const thumbnailObserver = "IntersectionObserver" in window
    ? new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) {
          continue;
        }
        const image = entry.target;
        thumbnailObserver.unobserve(image);
        const thumbnail = image.albumThumbnail;
        if (thumbnail) {
          loadThumbnailImage(image, thumbnail.preview, thumbnail.item);
        }
      }
    }, { rootMargin: "600px 0px" })
    : null;

  function preferredTheme() {
    const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
    if (savedTheme === "light" || savedTheme === "dark") {
      return savedTheme;
    }
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  function applyTheme(theme, persist = false) {
    document.documentElement.dataset.theme = theme;
    elements.themeToggle?.setAttribute(
      "aria-label",
      theme === "dark" ? "Dùng giao diện sáng" : "Dùng giao diện tối",
    );
    elements.themeToggle?.setAttribute(
      "title",
      theme === "dark" ? "Giao diện sáng" : "Giao diện tối",
    );
    document.querySelector('meta[name="theme-color"]')?.setAttribute(
      "content",
      theme === "dark" ? "#111618" : "#f7f8fa",
    );
    if (persist) {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    }
  }

  applyTheme(preferredTheme());

  function localPageEndpoint() {
    if (window.location.protocol !== "http:") {
      return null;
    }
    return {
      url: new URL("/", window.location.href).href,
      label: `${window.location.host} · Cục bộ`,
      kind: "local",
    };
  }

  function hiddenItemsStorageKey() {
    return `${HIDDEN_ITEMS_STORAGE_KEY}:${state.baseUrl}`;
  }

  function loadHiddenItems() {
    try {
      const parsed = JSON.parse(localStorage.getItem(hiddenItemsStorageKey()));
      state.hiddenIds = new Set(Array.isArray(parsed) ? parsed.filter((id) => typeof id === "string") : []);
    } catch {
      state.hiddenIds = new Set();
    }
    updateHiddenCount();
  }

  function saveHiddenItems() {
    try {
      localStorage.setItem(hiddenItemsStorageKey(), JSON.stringify([...state.hiddenIds]));
      updateHiddenCount();
      return true;
    } catch {
      showToast("Không thể lưu danh sách đã ẩn trong trình duyệt này.");
      return false;
    }
  }

  function updateHiddenCount() {
    const count = state.hiddenIds.size;
    elements.hiddenCount.textContent = numberFormatter.format(count);
    elements.hiddenCount.hidden = count === 0;
  }

  function updateNavigationUi() {
    for (const button of elements.navigationButtons) {
      const targetView = button.dataset.navView;
      const targetFilter = button.dataset.navFilter;
      const isActive = targetView === "hidden"
        ? state.view === "hidden"
        : state.view === "library" && targetFilter === state.filter;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-current", isActive ? "page" : "false");
    }
    for (const button of elements.filterButtons) {
      button.classList.toggle("is-active", button.dataset.filter === state.filter);
    }
  }

  function activeTimelineFilterCount() {
    return Object.values(state.timelineFilters).filter(Boolean).length;
  }

  function updateTimelineFilterUi() {
    const count = activeTimelineFilterCount();
    const hasAvailableFilters = state.facets.folders.length > 0 || state.facets.dates.length > 0;
    elements.timelineFilterButton.hidden = !state.mode || (!hasAvailableFilters && count === 0);
    elements.timelineFilterButton.classList.toggle("is-active", count > 0);
    elements.timelineFilterButton.setAttribute("aria-pressed", String(count > 0));
    elements.timelineFilterCount.textContent = String(count);
    elements.timelineFilterCount.hidden = count === 0;
  }

  function showToast(message, duration = 3200) {
    clearTimeout(state.toastTimer);
    elements.toast.textContent = message;
    elements.toast.hidden = false;
    state.toastTimer = window.setTimeout(() => {
      elements.toast.hidden = true;
    }, duration);
  }

  function endpointUrl(endpoint) {
    return new URL(endpoint.url).href;
  }

  function openDirectly() {
    if (state.baseUrl) {
      window.open(state.baseUrl, "_blank", "noopener,noreferrer");
    }
  }

  function setLoading(isLoading, message = "Đang tải…") {
    state.isLoading = isLoading;
    elements.scanStatus.hidden = !isLoading;
    elements.scanStatusText.textContent = message;
    elements.refreshButton.disabled = isLoading;
    updateEmptyState();
  }

  function setMode(mode) {
    state.mode = mode;
    elements.connectionMode.hidden = !mode;
    const isCloud = state.endpoint?.kind === "cloud";
    const labels = {
      api: isCloud ? "Cloud API" : "LAN API",
      directory: isCloud ? "Thư mục Cloud" : "Thư mục LAN",
      offline: "Ngoại tuyến",
    };
    elements.connectionMode.textContent = labels[mode] || "";
    elements.refreshButton.hidden = !mode;
    updateTimelineFilterUi();
  }

  function hideNotice() {
    elements.connectionNotice.hidden = true;
    elements.noticeOpenDirect.textContent = "Đăng nhập kho ảnh";
  }

  function showConnectionError(error) {
    const detail = error instanceof Error ? error.message : String(error);
    if (state.isLocalServer) {
      elements.noticeTitle.textContent = "Chưa kết nối được server album";
      elements.noticeMessage.textContent =
        `Không đọc được API tại ${state.baseUrl} (${detail}). Hãy kiểm tra cửa sổ My Album trên máy Windows rồi thử lại.`;
      elements.noticeOpenDirect.hidden = true;
    } else {
      elements.noticeTitle.textContent = "Cần mở khóa kho ảnh";
      elements.noticeMessage.textContent =
        `Không đọc được ${state.baseUrl} (${detail}). ` +
        "Hãy mở kho ảnh, hoàn tất đăng nhập Cloudflare Access rồi quay lại bấm Thử lại.";
      elements.noticeOpenDirect.textContent = "Đăng nhập kho ảnh";
      elements.noticeOpenDirect.hidden = false;
    }
    elements.connectionNotice.hidden = false;
  }

  function showOfflineNotice(error) {
    const detail = error instanceof Error ? error.message : String(error);
    elements.noticeTitle.textContent = "Đang dùng album ngoại tuyến";
    elements.noticeMessage.textContent =
      `Không kết nối được ${state.baseUrl} (${detail}). ` +
      "Những thumbnail và ảnh đã lưu vẫn có thể mở; bấm làm mới khi kho ảnh hoạt động lại.";
    elements.connectionNotice.hidden = false;
  }

  function showLegacyServerNotice() {
    elements.noticeTitle.textContent = "Đang dùng chế độ thư mục";
    elements.noticeMessage.textContent =
      "Kết nối Cloudflare đang hoạt động, nhưng máy Windows vẫn chạy server thư mục cơ bản. " +
      "Ảnh vẫn xem được; chạy gói Windows mới để có thumbnail video, preview nhẹ và lọc thời gian chính xác.";
    elements.noticeOpenDirect.textContent = "Mở kho ảnh";
    elements.noticeOpenDirect.hidden = state.isLocalServer;
    elements.connectionNotice.hidden = false;
  }

  function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) {
      return "";
    }
    const units = ["B", "KB", "MB", "GB", "TB"];
    const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const value = bytes / 1024 ** index;
    return `${value >= 10 || index === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[index]}`;
  }

  function formatDate(timestamp) {
    return Number.isFinite(timestamp) && timestamp > 0 ? dateFormatter.format(new Date(timestamp * 1000)) : "";
  }

  function itemTimestamp(item) {
    return Number(item.modified) || 0;
  }

  function itemDetail(item) {
    return [formatDate(itemTimestamp(item)), formatBytes(item.bytes)].filter(Boolean).join(" · ");
  }

  function localDateKey(timestamp) {
    if (!Number.isFinite(timestamp) || timestamp <= 0) {
      return "";
    }
    const date = new Date(timestamp * 1000);
    const year = String(date.getFullYear());
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function itemFolderKey(item) {
    return String(item.folderKey || item.folder || "Thư mục gốc");
  }

  function itemMatchesTimelineFilters(item) {
    const filters = state.timelineFilters;
    if (filters.folder && itemFolderKey(item) !== filters.folder) {
      return false;
    }
    if (!filters.year) {
      return true;
    }
    const dateKey = localDateKey(itemTimestamp(item));
    if (!dateKey || dateKey.slice(0, 4) !== filters.year) {
      return false;
    }
    if (filters.month && dateKey.slice(5, 7) !== filters.month.padStart(2, "0")) {
      return false;
    }
    return !filters.day || dateKey.slice(8, 10) === filters.day.padStart(2, "0");
  }

  function deriveFacets(items) {
    const folders = new Set();
    const dates = new Set();
    for (const item of items) {
      folders.add(itemFolderKey(item));
      const dateKey = localDateKey(itemTimestamp(item));
      if (dateKey) {
        dates.add(dateKey);
      }
    }
    return {
      folders: [...folders].sort(folderCollator.compare),
      dates: [...dates].sort().reverse(),
    };
  }

  function normalizeFacets(rawFacets) {
    const folders = Array.isArray(rawFacets?.folders)
      ? rawFacets.folders.map(String).filter(Boolean).sort(folderCollator.compare)
      : [];
    const dates = Array.isArray(rawFacets?.dates)
      ? rawFacets.dates.map(String).filter((date) => /^\d{4}-\d{2}-\d{2}$/.test(date)).sort().reverse()
      : [];
    return { folders: [...new Set(folders)], dates: [...new Set(dates)] };
  }

  function folderFilterLabel(folder) {
    return folder === "." ? "Thư mục gốc" : folder.replaceAll("/", " / ");
  }

  function setSelectOptions(select, placeholder, values, selected, labelForValue = String) {
    const normalizedValues = [...new Set(values.map(String))];
    if (selected && !normalizedValues.includes(selected)) {
      normalizedValues.push(selected);
    }
    const fragment = document.createDocumentFragment();
    fragment.append(new Option(placeholder, ""));
    for (const value of normalizedValues) {
      fragment.append(new Option(labelForValue(value), value));
    }
    select.replaceChildren(fragment);
    select.value = selected && normalizedValues.includes(selected) ? selected : "";
    return select.value;
  }

  function populateTimelineFilterDialog(filters = state.timelineFilters) {
    const folders = [...state.facets.folders].sort(folderCollator.compare);
    setSelectOptions(
      elements.folderFilter,
      "Tất cả thư mục",
      folders,
      filters.folder,
      folderFilterLabel,
    );

    const years = [...new Set(state.facets.dates.map((date) => date.slice(0, 4)))].sort().reverse();
    const year = setSelectOptions(elements.yearFilter, "Tất cả năm", years, filters.year);
    const months = year
      ? [...new Set(state.facets.dates
        .filter((date) => date.startsWith(`${year}-`))
        .map((date) => date.slice(5, 7)))].sort((left, right) => Number(left) - Number(right))
      : [];
    const month = setSelectOptions(
      elements.monthFilter,
      "Tất cả tháng",
      months,
      year ? filters.month : "",
      (value) => monthFormatter.format(new Date(2024, Number(value) - 1, 1)),
    );
    elements.monthFilter.disabled = !year || months.length === 0;

    const days = year && month
      ? [...new Set(state.facets.dates
        .filter((date) => date.startsWith(`${year}-${month.padStart(2, "0")}-`))
        .map((date) => date.slice(8, 10)))].sort((left, right) => Number(left) - Number(right))
      : [];
    setSelectOptions(
      elements.dayFilter,
      "Tất cả ngày",
      days,
      year && month ? filters.day : "",
      (value) => `Ngày ${Number(value)}`,
    );
    elements.dayFilter.disabled = !year || !month || days.length === 0;
  }

  function showTimelineFilterDialog() {
    populateTimelineFilterDialog();
    elements.filterDialog.showModal();
    requestAnimationFrame(() => elements.folderFilter.focus());
  }

  function closeTimelineFilterDialog() {
    if (elements.filterDialog.open) {
      elements.filterDialog.close();
    }
  }

  function readTimelineFilterForm() {
    return {
      folder: elements.folderFilter.value,
      year: elements.yearFilter.value,
      month: elements.yearFilter.value ? elements.monthFilter.value : "",
      day: elements.yearFilter.value && elements.monthFilter.value ? elements.dayFilter.value : "",
    };
  }

  function canUseCacheStorage() {
    return "caches" in window && typeof window.caches?.open === "function";
  }

  function blobCacheKey(cacheName, sourceUrl) {
    const url = new URL("./__offline/blob", window.location.href);
    url.search = "";
    url.searchParams.set("cache", cacheName);
    url.searchParams.set("source", sourceUrl);
    return url.href;
  }

  async function fetchMediaResponse(url, signal) {
    const response = await fetch(url, {
      cache: "no-store",
      credentials: state.endpoint?.kind === "cloud" ? "include" : "same-origin",
      mode: "cors",
      signal,
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return response;
  }

  async function readCachedBlob(cacheName, url) {
    if (!canUseCacheStorage()) {
      return null;
    }
    const cache = await caches.open(cacheName);
    const response = await cache.match(blobCacheKey(cacheName, url));
    if (!response) {
      return null;
    }
    return response.blob();
  }

  async function loadThumbnailBlob(url, signal) {
    const cachedBlob = await readCachedBlob(THUMBNAIL_CACHE_NAME, url);
    if (cachedBlob) {
      return cachedBlob;
    }

    const response = await fetchMediaResponse(url, signal);
    if (canUseCacheStorage()) {
      const cache = await caches.open(THUMBNAIL_CACHE_NAME);
      cache.put(blobCacheKey(THUMBNAIL_CACHE_NAME, url), response.clone()).catch(() => {});
    }
    return response.blob();
  }

  function readViewedImageCacheIndex() {
    try {
      const parsed = JSON.parse(localStorage.getItem(VIEWED_IMAGE_CACHE_INDEX_KEY));
      if (!Array.isArray(parsed)) {
        return [];
      }
      return parsed.filter((entry) =>
        entry && typeof entry.url === "string" && Number.isFinite(entry.bytes) && Number.isFinite(entry.lastAccess));
    } catch {
      return [];
    }
  }

  function writeViewedImageCacheIndex(entries) {
    try {
      localStorage.setItem(VIEWED_IMAGE_CACHE_INDEX_KEY, JSON.stringify(entries));
    } catch {
      // The image remains cached even if the optional LRU index cannot be stored.
    }
  }

  function touchViewedImageCache(url, bytes) {
    const entries = readViewedImageCacheIndex();
    const existing = entries.find((entry) => entry.url === url);
    if (existing) {
      existing.bytes = bytes || existing.bytes;
      existing.lastAccess = Date.now();
    } else {
      entries.push({ url, bytes, lastAccess: Date.now() });
    }
    writeViewedImageCacheIndex(entries);
  }

  async function storeViewedImage(url, blob) {
    if (!canUseCacheStorage()) {
      return false;
    }

    const cache = await caches.open(VIEWED_IMAGE_CACHE_NAME);
    const response = new Response(blob, {
      headers: {
        "Content-Length": String(blob.size),
        "Content-Type": blob.type || "application/octet-stream",
        "X-My-Album-Cached-At": new Date().toISOString(),
      },
    });
    await cache.put(blobCacheKey(VIEWED_IMAGE_CACHE_NAME, url), response);

    const entries = readViewedImageCacheIndex().filter((entry) => entry.url !== url);
    entries.push({ url, bytes: blob.size, lastAccess: Date.now() });
    entries.sort((left, right) => left.lastAccess - right.lastAccess);

    let totalBytes = entries.reduce((sum, entry) => sum + entry.bytes, 0);
    while (totalBytes > VIEWED_IMAGE_CACHE_MAX_BYTES && entries.length > 0) {
      const oldest = entries.shift();
      totalBytes -= oldest.bytes;
      await cache.delete(blobCacheKey(VIEWED_IMAGE_CACHE_NAME, oldest.url));
    }
    writeViewedImageCacheIndex(entries);
    return entries.some((entry) => entry.url === url);
  }

  function mediaExtension(pathname) {
    const name = pathname.split("/").pop() ?? "";
    const dot = name.lastIndexOf(".");
    return dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";
  }

  function safeDecode(value) {
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }

  function relativePath(url) {
    const basePath = new URL(state.baseUrl).pathname;
    const pathname = safeDecode(new URL(url).pathname);
    return pathname.slice(basePath.length).replace(/^\/+/, "");
  }

  function makeDirectoryThumbnailUrl(relative) {
    const base = new URL(state.baseUrl);
    const encoded = relative
      .split("/")
      .map((part) => encodeURIComponent(part))
      .join("/");
    return new URL(`_thumbnails/${encoded}.jpg`, base).href;
  }

  async function makeHashedDirectoryThumbnailUrl(relative) {
    const digest = await crypto.subtle.digest("SHA-1", textEncoder.encode(relative));
    const hash = [...new Uint8Array(digest)]
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("")
      .slice(0, 16);
    return new URL(`thumbs/${hash}.jpg`, state.baseUrl).href;
  }

  function directoryItemFromUrl(url) {
    const parsed = new URL(url);
    const extension = mediaExtension(parsed.pathname);
    const type = IMAGE_EXTENSIONS.has(extension) ? "image" : VIDEO_EXTENSIONS.has(extension) ? "video" : null;
    if (!type) {
      return null;
    }

    const relative = relativePath(url);
    const parts = relative.split("/");
    const encodedName = parts.pop() ?? relative;
    const name = safeDecode(encodedName);
    const folderKey = parts.map(safeDecode).join("/") || ".";
    const folder = folderFilterLabel(folderKey);

    return {
      id: url,
      url,
      preview: url,
      type,
      extension,
      relative,
      name,
      folder,
      thumbnail: null,
      bytes: 0,
      modified: 0,
      folderKey,
      source: "directory",
      thumbnailFallback: type === "image" ? makeDirectoryThumbnailUrl(relative) : null,
    };
  }

  function normalizeApiItem(rawItem) {
    const name = String(rawItem.fileName || rawItem.name || "Không tên");
    const folderKey = rawItem.folder ? String(rawItem.folder) : ".";
    const folder = folderKey !== "." ? folderKey.replaceAll("/", " / ") : "Thư mục gốc";
    return {
      id: String(rawItem.id),
      url: new URL(String(rawItem.media), state.baseUrl).href,
      preview: new URL(String(rawItem.view || rawItem.media), state.baseUrl).href,
      thumbnail: new URL(String(rawItem.thumbnail), state.baseUrl).href,
      type: rawItem.type === "video" ? "video" : "image",
      extension: String(rawItem.extension || mediaExtension(name)),
      relative: `${rawItem.folder || ""}/${name}`,
      name,
      folder,
      folderKey,
      bytes: Number(rawItem.bytes) || 0,
      modified: Number(rawItem.modified) || 0,
      source: "api",
      thumbnailFallback: null,
    };
  }

  function catalogCacheUrl() {
    const url = new URL("./__offline/catalog.json", window.location.href);
    url.search = "";
    url.searchParams.set("endpoint", state.baseUrl);
    return url.href;
  }

  async function saveCachedCatalog() {
    if (!canUseCacheStorage() || !state.endpoint || !["api", "directory"].includes(state.mode)) {
      return;
    }
    if (state.mode === "api" && (
      state.filter !== "all" || state.query.trim() || activeTimelineFilterCount() > 0
    )) {
      return;
    }

    const cache = await caches.open(CATALOG_CACHE_NAME);
    const payload = {
      version: 1,
      endpoint: state.baseUrl,
      savedAt: Date.now(),
      sourceMode: state.mode,
      items: state.items,
      stats: state.stats,
    };
    await cache.put(catalogCacheUrl(), new Response(JSON.stringify(payload), {
      headers: { "Content-Type": "application/json; charset=utf-8" },
    }));
  }

  async function restoreCachedCatalog() {
    if (!canUseCacheStorage() || !state.endpoint) {
      return false;
    }

    try {
      const cache = await caches.open(CATALOG_CACHE_NAME);
      const response = await cache.match(catalogCacheUrl());
      if (!response) {
        return false;
      }
      const payload = await response.json();
      if (payload?.version !== 1 || payload.endpoint !== state.baseUrl || !Array.isArray(payload.items)) {
        return false;
      }

      const items = payload.items.filter((item) =>
        item && typeof item.url === "string" && typeof item.name === "string" &&
        (item.type === "image" || item.type === "video"));
      if (items.length === 0) {
        return false;
      }

      state.items = items;
      state.visibleItems = items;
      state.total = items.length;
      state.stats = payload.stats || {
        total: items.length,
        images: items.filter((item) => item.type === "image").length,
        videos: items.filter((item) => item.type === "video").length,
      };
      state.hasMore = false;
      state.renderedCount = 0;
      state.facets = deriveFacets(items);
      setMode("offline");
      refreshDirectoryItems(false);
      return true;
    } catch {
      return false;
    }
  }

  async function fetchWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, {
        cache: "no-store",
        credentials: state.endpoint?.kind === "cloud" ? "include" : "same-origin",
        mode: "cors",
        signal: controller.signal,
      });
    } catch (error) {
      if (controller.signal.aborted) {
        throw new Error("quá thời gian chờ server");
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function probeApi() {
    const response = await fetchWithTimeout(new URL("healthz", state.baseUrl), PROBE_TIMEOUT_MS);
    if (response.status === 404) {
      throw new ApiUnavailableError("Không có API album");
    }
    const contentType = response.headers.get("content-type") || "";
    if (!response.ok || !contentType.includes("application/json")) {
      throw new Error(`health check HTTP ${response.status}`);
    }
    const payload = await response.json();
    if (payload.status !== "ok") {
      throw new Error("health check không hợp lệ");
    }
  }

  function apiItemsUrl({ offset, force }) {
    const url = new URL("api/items", state.baseUrl);
    url.searchParams.set("offset", String(offset));
    url.searchParams.set("limit", String(PAGE_SIZE));
    url.searchParams.set("type", state.filter);
    url.searchParams.set("sort", state.sort);
    if (state.query.trim()) {
      url.searchParams.set("q", state.query.trim());
    }
    for (const [name, value] of Object.entries(state.timelineFilters)) {
      if (value) {
        url.searchParams.set(name, value);
      }
    }
    if (force) {
      url.searchParams.set("refresh", "1");
    }
    return url;
  }

  async function fetchApiPage({ offset, force, version }) {
    const response = await fetchWithTimeout(apiItemsUrl({ offset, force }), API_TIMEOUT_MS);
    const contentType = response.headers.get("content-type") || "";
    if (response.status === 404 || !contentType.includes("application/json")) {
      throw new ApiUnavailableError("Server không trả API JSON");
    }
    if (!response.ok) {
      throw new Error(`API HTTP ${response.status}`);
    }
    const payload = await response.json();
    if (version !== state.requestVersion) {
      return null;
    }
    if (!Array.isArray(payload.items)) {
      throw new Error("Dữ liệu API không hợp lệ");
    }
    return payload;
  }

  async function loadApiPage({ reset = false, force = false, version = state.requestVersion } = {}) {
    if (state.isLoadingMore && !reset) {
      return false;
    }
    if (!reset && !state.hasMore) {
      return false;
    }

    const offset = reset ? 0 : state.items.length;
    state.isLoadingMore = !reset;
    if (!reset) {
      elements.scanStatus.hidden = false;
      elements.scanStatusText.textContent = "Đang tải thêm…";
    }

    try {
      const payload = await fetchApiPage({ offset, force, version });
      if (!payload) {
        return false;
      }
      const nextItems = payload.items.map(normalizeApiItem);
      state.items = reset ? nextItems : [...state.items, ...nextItems];
      state.total = Number(payload.total) || 0;
      state.stats = payload.stats || null;
      state.hasMore = Boolean(payload.hasMore);
      if (payload.facets) {
        state.facets = normalizeFacets(payload.facets);
      }
      setMode("api");

      if (reset) {
        clearMediaGrid();
        state.renderedCount = 0;
      }
      updateVisibleItems();
      renderNextPage(Math.max(nextItems.length || PAGE_SIZE, state.visibleItems.length - state.renderedCount));
      updateSummary();
      updateEmptyState();
      saveCachedCatalog().catch(() => {});
      return true;
    } finally {
      state.isLoadingMore = false;
      if (!state.isLoading) {
        elements.scanStatus.hidden = true;
      }
    }
  }

  function isInsideAlbum(candidate) {
    const base = new URL(state.baseUrl);
    return (
      candidate.protocol === base.protocol &&
      candidate.hostname === base.hostname &&
      candidate.port === base.port &&
      candidate.pathname.startsWith(base.pathname)
    );
  }

  function parseDirectory(html, directoryUrl) {
    const documentNode = new DOMParser().parseFromString(html, "text/html");
    const directories = [];
    const media = [];

    for (const anchor of documentNode.querySelectorAll("a[href]")) {
      const rawHref = anchor.getAttribute("href") ?? "";
      if (!rawHref || rawHref.startsWith("#") || rawHref.startsWith("?")) {
        continue;
      }

      let candidate;
      try {
        candidate = new URL(rawHref, directoryUrl);
      } catch {
        continue;
      }

      candidate.hash = "";
      candidate.search = "";
      if (!isInsideAlbum(candidate)) {
        continue;
      }

      const currentPath = new URL(directoryUrl).pathname;
      if (candidate.pathname === currentPath || candidate.pathname.length < currentPath.length) {
        continue;
      }

      const decodedParts = safeDecode(candidate.pathname).split("/").filter(Boolean);
      const lastPart = (decodedParts.at(-1) ?? "").toLocaleLowerCase("en");
      const appearsToBeDirectory = rawHref.endsWith("/") || anchor.textContent.trim().endsWith("/");

      if (appearsToBeDirectory) {
        if (!SKIPPED_DIRECTORIES.has(lastPart)) {
          if (!candidate.pathname.endsWith("/")) {
            candidate.pathname += "/";
          }
          directories.push(candidate.href);
        }
        continue;
      }

      const item = directoryItemFromUrl(candidate.href);
      if (item) {
        media.push(item);
      }
    }

    return { directories, media };
  }

  async function fetchDirectory(url, version) {
    const response = await fetchWithTimeout(url, DIRECTORY_TIMEOUT_MS);
    if (version !== state.requestVersion) {
      return null;
    }
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return parseDirectory(await response.text(), url);
  }

  async function scanDirectory(version) {
    const pending = [state.baseUrl];
    const queued = new Set(pending);
    const visited = new Set();
    const mediaUrls = new Set();
    let completedDirectories = 0;

    state.items = [];
    state.visibleItems = [];
    state.total = 0;
    state.stats = null;
    state.hasMore = false;
    setMode("directory");

    while (pending.length > 0 && version === state.requestVersion) {
      const batch = pending.splice(0, MAX_CONCURRENT_REQUESTS);
      const results = await Promise.all(batch.map((url) => fetchDirectory(url, version)));

      for (let index = 0; index < batch.length; index += 1) {
        const directoryUrl = batch[index];
        const result = results[index];
        visited.add(directoryUrl);
        completedDirectories += 1;
        if (!result) {
          continue;
        }

        for (const nestedUrl of result.directories) {
          if (!visited.has(nestedUrl) && !queued.has(nestedUrl)) {
            queued.add(nestedUrl);
            pending.push(nestedUrl);
          }
        }

        for (const item of result.media) {
          if (!mediaUrls.has(item.url)) {
            mediaUrls.add(item.url);
            state.items.push(item);
          }
        }
      }

      elements.scanStatusText.textContent =
        `${numberFormatter.format(state.items.length)} mục · ${completedDirectories} thư mục`;
    }

    if (version !== state.requestVersion) {
      return;
    }
    state.total = state.items.length;
    state.stats = {
      total: state.items.length,
      images: state.items.filter((item) => item.type === "image").length,
      videos: state.items.filter((item) => item.type === "video").length,
    };
    state.facets = deriveFacets(state.items);
    updateTimelineFilterUi();
    refreshDirectoryItems(false);
    saveCachedCatalog().catch(() => {});
  }

  function renderSkeletons() {
    clearMediaGrid();
    const fragment = document.createDocumentFragment();
    const grid = document.createElement("div");
    grid.className = "skeleton-grid";
    for (let index = 0; index < 12; index += 1) {
      const card = document.createElement("div");
      card.className = "media-card is-skeleton";
      card.setAttribute("aria-hidden", "true");
      const preview = document.createElement("span");
      preview.className = "media-preview";
      const meta = document.createElement("span");
      meta.className = "media-meta";
      const firstLine = document.createElement("span");
      const secondLine = document.createElement("span");
      firstLine.className = "skeleton-line";
      secondLine.className = "skeleton-line";
      meta.append(firstLine, secondLine);
      card.append(preview, meta);
      grid.append(card);
    }
    fragment.append(grid);
    elements.mediaGrid.append(fragment);
  }

  function compareDirectoryItems(left, right) {
    const collator = compareDirectoryItems.collator ??= new Intl.Collator("vi", {
      numeric: true,
      sensitivity: "base",
    });
    if (state.sort === "name-desc") {
      return collator.compare(right.name, left.name);
    }
    if (state.sort === "name-asc") {
      return collator.compare(left.name, right.name);
    }
    if (state.sort === "newest" || state.sort === "oldest") {
      const direction = state.sort === "newest" ? -1 : 1;
      const dateDifference = (itemTimestamp(left) - itemTimestamp(right)) * direction;
      if (dateDifference !== 0) {
        return dateDifference;
      }
    }
    return collator.compare(left.relative, right.relative);
  }

  function updateVisibleItems() {
    const normalizedQuery = state.query.trim().toLocaleLowerCase("vi");
    state.visibleItems = state.items
      .filter((item) => state.hiddenIds.has(item.id) === (state.view === "hidden"))
      .filter((item) => state.filter === "all" || item.type === state.filter)
      .filter(itemMatchesTimelineFilters)
      .filter((item) => !normalizedQuery || `${item.name} ${item.folder}`.toLocaleLowerCase("vi").includes(normalizedQuery))
      .sort(compareDirectoryItems);
  }

  function refreshDirectoryItems(keepRenderLimit = false) {
    updateVisibleItems();
    if (state.mode !== "api") {
      state.total = state.visibleItems.length;
    }

    const targetCount = keepRenderLimit ? Math.max(state.renderedCount, PAGE_SIZE) : PAGE_SIZE;
    state.renderedCount = 0;
    clearMediaGrid();
    renderNextPage(targetCount);
    updateSummary();
    updateEmptyState();
  }

  async function thumbnailSources(item) {
    if (item.source === "directory") {
      let hashedThumbnail = null;
      try {
        hashedThumbnail = await makeHashedDirectoryThumbnailUrl(item.relative);
      } catch {
        // The mirrored _thumbnails layout remains a fallback for older setups.
      }
      return [hashedThumbnail, item.type === "image" ? item.thumbnailFallback : null].filter(Boolean);
    }

    if (!item.thumbnail) {
      return [];
    }
    return [item.thumbnail];
  }

  function releaseThumbnailImage(image) {
    thumbnailObserver?.unobserve(image);
    image.albumThumbnailAbort?.abort();
    image.albumThumbnailAbort = null;
    if (image.albumThumbnailObjectUrl) {
      URL.revokeObjectURL(image.albumThumbnailObjectUrl);
      image.albumThumbnailObjectUrl = null;
    }
    image.removeAttribute("src");
    image.albumThumbnail = null;
  }

  function clearMediaGrid() {
    for (const image of elements.mediaGrid.querySelectorAll(".media-preview img")) {
      releaseThumbnailImage(image);
    }
    elements.mediaGrid.replaceChildren();
  }

  function showThumbnailBlob(image, blob) {
    return new Promise((resolve, reject) => {
      const objectUrl = URL.createObjectURL(blob);
      image.albumThumbnailObjectUrl = objectUrl;

      const releaseObjectUrl = () => {
        if (image.albumThumbnailObjectUrl === objectUrl) {
          URL.revokeObjectURL(objectUrl);
          image.albumThumbnailObjectUrl = null;
        }
      };
      image.addEventListener("load", () => {
        releaseObjectUrl();
        resolve();
      }, { once: true });
      image.addEventListener("error", () => {
        releaseObjectUrl();
        reject(new Error("Thumbnail không hợp lệ"));
      }, { once: true });
      image.src = objectUrl;
    });
  }

  async function loadThumbnailImage(image, preview, item) {
    const controller = new AbortController();
    image.albumThumbnailAbort = controller;
    try {
      const fallbacks = await thumbnailSources(item);
      for (const url of fallbacks) {
        try {
          const blob = await loadThumbnailBlob(url, controller.signal);
          if (!image.isConnected || controller.signal.aborted) {
            return;
          }
          await showThumbnailBlob(image, blob);
          image.albumThumbnailAbort = null;
          return;
        } catch (error) {
          if (controller.signal.aborted) {
            return;
          }
        }
      }

      releaseThumbnailImage(image);
      image.remove();
      if (item.type === "video") {
        preview.classList.add("video-preview");
      }
    } catch {
      releaseThumbnailImage(image);
      image.remove();
      if (item.type === "video") {
        preview.classList.add("video-preview");
      }
    }
  }

  function addPreviewImage(preview, item) {
    const image = document.createElement("img");
    image.alt = "";
    image.loading = "lazy";
    image.decoding = "async";
    image.albumThumbnail = { preview, item };
    preview.prepend(image);

    if (thumbnailObserver) {
      thumbnailObserver.observe(image);
    } else {
      loadThumbnailImage(image, preview, item);
    }
  }

  function updateSelectionUi() {
    const selectedCount = state.selectedIds.size;
    const allVisibleSelected = state.visibleItems.length > 0 &&
      state.visibleItems.every((item) => state.selectedIds.has(item.id));

    elements.mediaGrid.classList.toggle("is-selecting", state.selectionMode);
    document.body.classList.toggle("has-selection", state.selectionMode);
    elements.selectionBar.hidden = !state.selectionMode;
    elements.selectButton.hidden = !state.mode || state.visibleItems.length === 0 || state.selectionMode;
    elements.selectionCount.textContent = `${numberFormatter.format(selectedCount)} mục đã chọn`;
    elements.selectAllButton.textContent = allVisibleSelected ? "Bỏ chọn tất cả" : "Chọn tất cả";
    elements.selectAllButton.disabled = state.visibleItems.length === 0 || state.isDownloading;
    elements.downloadSelected.disabled = selectedCount === 0 || state.isDownloading;
    elements.hideSelected.disabled = selectedCount === 0 || state.isDownloading;
    elements.restoreSelected.disabled = selectedCount === 0 || state.isDownloading;
    elements.hideSelected.hidden = state.view === "hidden";
    elements.restoreSelected.hidden = state.view !== "hidden";

    for (const card of elements.mediaGrid.querySelectorAll(".media-card:not(.is-skeleton)")) {
      const item = state.visibleItems[Number(card.dataset.index)];
      const isSelected = Boolean(item && state.selectedIds.has(item.id));
      card.classList.toggle("is-selected", isSelected);
      if (state.selectionMode) {
        card.setAttribute("aria-pressed", String(isSelected));
        card.setAttribute("aria-label", `${isSelected ? "Bỏ chọn" : "Chọn"} ${item?.name || "mục"}`);
      } else {
        card.removeAttribute("aria-pressed");
        if (item) {
          card.setAttribute("aria-label", `Mở ${item.name}`);
        }
      }
    }

    const groupSelection = new Map();
    for (const item of state.visibleItems) {
      const key = timelineGroupKey(item);
      const status = groupSelection.get(key) || { total: 0, selected: 0 };
      status.total += 1;
      if (state.selectedIds.has(item.id)) {
        status.selected += 1;
      }
      groupSelection.set(key, status);
    }
    for (const button of elements.mediaGrid.querySelectorAll("[data-select-group]")) {
      const status = groupSelection.get(button.dataset.selectGroup);
      const isSelected = Boolean(status && status.total > 0 && status.selected === status.total);
      button.classList.toggle("is-selected", isSelected);
      button.setAttribute("aria-pressed", String(isSelected));
    }
  }

  function enterSelectionMode(initialIndex = -1) {
    if (state.visibleItems.length === 0) {
      return;
    }
    state.selectionMode = true;
    state.lastSelectedIndex = -1;
    if (initialIndex >= 0 && state.visibleItems[initialIndex]) {
      state.selectedIds.add(state.visibleItems[initialIndex].id);
      state.lastSelectedIndex = initialIndex;
    }
    updateSelectionUi();
  }

  function exitSelectionMode() {
    state.downloadAbortController?.abort();
    state.downloadAbortController = null;
    state.isDownloading = false;
    state.selectionMode = false;
    state.selectedIds.clear();
    state.lastSelectedIndex = -1;
    elements.selectionBar.classList.remove("is-busy");
    elements.selectionProgress.hidden = true;
    elements.selectionProgressBar.style.width = "0%";
    updateSelectionUi();
  }

  function toggleItemSelection(index, useRange = false) {
    const item = state.visibleItems[index];
    if (!item) {
      return;
    }

    if (useRange && state.lastSelectedIndex >= 0) {
      const start = Math.min(state.lastSelectedIndex, index);
      const end = Math.max(state.lastSelectedIndex, index);
      for (let cursor = start; cursor <= end; cursor += 1) {
        state.selectedIds.add(state.visibleItems[cursor].id);
      }
    } else if (state.selectedIds.has(item.id)) {
      state.selectedIds.delete(item.id);
    } else {
      state.selectedIds.add(item.id);
    }

    state.lastSelectedIndex = index;
    updateSelectionUi();
  }

  function toggleSelectAll() {
    const allSelected = state.visibleItems.length > 0 &&
      state.visibleItems.every((item) => state.selectedIds.has(item.id));
    for (const item of state.visibleItems) {
      if (allSelected) {
        state.selectedIds.delete(item.id);
      } else {
        state.selectedIds.add(item.id);
      }
    }
    state.lastSelectedIndex = -1;
    updateSelectionUi();
  }

  function toggleTimelineGroup(groupKey) {
    const groupItems = state.visibleItems.filter((item) => timelineGroupKey(item) === groupKey);
    if (groupItems.length === 0) {
      return;
    }
    const allSelected = groupItems.every((item) => state.selectedIds.has(item.id));
    state.selectionMode = true;
    state.lastSelectedIndex = -1;
    for (const item of groupItems) {
      if (allSelected) {
        state.selectedIds.delete(item.id);
      } else {
        state.selectedIds.add(item.id);
      }
    }
    updateSelectionUi();
  }

  function applyHiddenAction(shouldHide) {
    const selectedIds = [...state.selectedIds];
    if (selectedIds.length === 0) {
      return;
    }

    const previousHiddenIds = new Set(state.hiddenIds);
    for (const id of selectedIds) {
      if (shouldHide) {
        state.hiddenIds.add(id);
      } else {
        state.hiddenIds.delete(id);
      }
    }
    if (!saveHiddenItems()) {
      state.hiddenIds = previousHiddenIds;
      updateHiddenCount();
      return;
    }

    const count = selectedIds.length;
    exitSelectionMode();
    refreshDirectoryItems(false);
    showToast(shouldHide
      ? `Đã ẩn ${numberFormatter.format(count)} mục khỏi thư viện.`
      : `Đã đưa ${numberFormatter.format(count)} mục trở lại thư viện.`);
  }

  function timelineGroupKey(item) {
    if (state.sort === "name-asc" || state.sort === "name-desc") {
      const firstCharacter = item.name.trim().charAt(0).toLocaleUpperCase("vi") || "#";
      return `name:${firstCharacter}`;
    }
    const timestamp = itemTimestamp(item);
    if (timestamp > 0) {
      return `date:${localDateKey(timestamp)}`;
    }
    return `folder:${item.folder || "Thư mục gốc"}`;
  }

  function timelineGroup(item) {
    const key = timelineGroupKey(item);
    if (key.startsWith("name:")) {
      return { key, title: key.slice(5) };
    }
    if (key.startsWith("date:")) {
      const date = new Date(itemTimestamp(item) * 1000);
      const formatted = timelineDateFormatter.format(date);
      return { key, title: formatted.charAt(0).toLocaleUpperCase("vi") + formatted.slice(1) };
    }
    return { key, title: item.folder || "Thư mục gốc" };
  }

  function createTimelineSection(group) {
    const section = document.createElement("section");
    section.className = "timeline-section";
    section.dataset.groupKey = group.key;

    const header = document.createElement("header");
    header.className = "timeline-header";
    const select = document.createElement("button");
    select.type = "button";
    select.className = "timeline-select-button";
    select.dataset.selectGroup = group.key;
    select.setAttribute("aria-label", `Chọn nhóm ${group.title}`);
    select.setAttribute("aria-pressed", "false");
    select.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 12 3 3 7-7" /></svg>';
    const title = document.createElement("h2");
    title.textContent = group.title;
    const count = document.createElement("span");
    count.className = "timeline-count";
    count.dataset.count = "0";
    count.textContent = "0 mục";
    header.append(select, title, count);

    const grid = document.createElement("div");
    grid.className = "timeline-grid";
    section.append(header, grid);
    return section;
  }

  function increaseTimelineCount(section) {
    const count = section.querySelector(".timeline-count");
    const nextCount = Number(count.dataset.count || 0) + 1;
    count.dataset.count = String(nextCount);
    count.textContent = `${numberFormatter.format(nextCount)} mục`;
  }

  function createMediaCard(item, index) {
    const fragment = elements.mediaCardTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".media-card");
    const preview = fragment.querySelector(".media-preview");
    const name = fragment.querySelector(".media-name");
    const folder = fragment.querySelector(".media-folder");
    const detail = fragment.querySelector(".media-detail");

    card.dataset.index = String(index);
    card.dataset.itemId = item.id;
    card.setAttribute("aria-label", `Mở ${item.name}`);
    name.textContent = item.name;
    folder.textContent = item.folder;
    detail.textContent = itemDetail(item);

    const typeBadge = document.createElement("span");
    typeBadge.className = "media-type";
    typeBadge.textContent = item.extension;
    preview.append(typeBadge);
    addPreviewImage(preview, item);

    if (state.selectedIds.has(item.id)) {
      card.classList.add("is-selected");
      card.setAttribute("aria-pressed", "true");
    }

    return fragment;
  }

  function renderNextPage(targetCount = PAGE_SIZE) {
    if (state.renderedCount >= state.visibleItems.length) {
      return;
    }
    const end = Math.min(state.renderedCount + targetCount, state.visibleItems.length);
    let activeSection = elements.mediaGrid.lastElementChild?.classList.contains("timeline-section")
      ? elements.mediaGrid.lastElementChild
      : null;
    for (let index = state.renderedCount; index < end; index += 1) {
      const item = state.visibleItems[index];
      const group = timelineGroup(item);
      if (!activeSection || activeSection.dataset.groupKey !== group.key) {
        activeSection = createTimelineSection(group);
        elements.mediaGrid.append(activeSection);
      }
      activeSection.querySelector(".timeline-grid").append(createMediaCard(item, index));
      increaseTimelineCount(activeSection);
    }
    state.renderedCount = end;
    updateSelectionUi();
  }

  function updateSummary() {
    elements.albumTitle.textContent = state.view === "hidden"
      ? "Đã ẩn"
      : state.filter === "image"
        ? "Ảnh"
        : state.filter === "video"
          ? "Video"
          : "Dòng thời gian";
    if (!state.endpoint) {
      elements.albumSummary.textContent = "Nhập IP và cổng của máy lưu album để bắt đầu.";
      return;
    }

    if (state.view === "hidden") {
      const qualifier = state.filter !== "all" || state.query.trim() || activeTimelineFilterCount() > 0
        ? " phù hợp"
        : "";
      elements.albumSummary.textContent =
        `${numberFormatter.format(state.visibleItems.length)} mục${qualifier} · Chỉ ẩn trên trình duyệt này`;
      return;
    }

    const stats = state.stats || { images: 0, videos: 0 };
    const hiddenLoadedItems = state.items.filter((item) => state.hiddenIds.has(item.id));
    const hiddenImages = hiddenLoadedItems.filter((item) => item.type === "image").length;
    const hiddenVideos = hiddenLoadedItems.filter((item) => item.type === "video").length;
    const visibleImages = Math.max(0, (stats.images || 0) - hiddenImages);
    const visibleVideos = Math.max(0, (stats.videos || 0) - hiddenVideos);
    const baseSummary = `${numberFormatter.format(visibleImages)} ảnh · ${numberFormatter.format(visibleVideos)} video`;
    const hasActiveQuery = state.filter !== "all" || Boolean(state.query.trim()) || activeTimelineFilterCount() > 0;
    elements.albumSummary.textContent = hasActiveQuery
      ? `${numberFormatter.format(state.total)} kết quả · ${baseSummary}`
      : baseSummary;
  }

  function updateEmptyState() {
    const hasVisibleItems = state.visibleItems.length > 0;
    elements.emptyState.hidden = hasVisibleItems || state.isLoading;
    elements.emptyConnect.textContent = state.endpoint ? "Đổi IP và cổng" : "Nhập IP và cổng";
    elements.emptyConnect.hidden = Boolean(state.endpoint);
    if (state.endpoint && state.mode && state.view === "hidden" && !hasVisibleItems) {
      elements.emptyTitle.textContent = state.filter !== "all" || state.query.trim()
        ? "Không có kết quả"
        : "Chưa có mục đã ẩn";
      elements.emptyCopy.textContent = state.filter !== "all" || state.query.trim()
        ? "Thử từ khóa khác hoặc đổi bộ lọc nội dung."
        : "Ảnh và video bạn ẩn sẽ xuất hiện ở đây để có thể khôi phục bất cứ lúc nào.";
    } else if (state.endpoint && state.mode && !hasVisibleItems) {
      elements.emptyTitle.textContent = "Không có kết quả";
      elements.emptyCopy.textContent = "Thử từ khóa khác, đổi bộ lọc hoặc làm mới album.";
    } else {
      elements.emptyTitle.textContent = "Chưa có nội dung";
      elements.emptyCopy.textContent = "Kết nối tới máy lưu album để xem ảnh và video.";
    }
    updateSelectionUi();
  }

  function releaseViewerMedia() {
    state.viewerLoadToken += 1;
    state.viewerAbortController?.abort();
    state.viewerAbortController = null;
    clearTimeout(state.viewerCacheTimer);
    state.viewerCacheTimer = null;

    const video = elements.viewerStage.querySelector("video");
    if (video) {
      video.pause();
      video.removeAttribute("src");
      video.load();
    }
    const image = elements.viewerStage.querySelector("img");
    image?.removeAttribute("src");

    if (state.viewerObjectUrl) {
      URL.revokeObjectURL(state.viewerObjectUrl);
    }
    state.viewerObjectUrl = null;
    state.viewerBlob = null;
    state.viewerCacheUrl = null;
    if (elements.viewerOfflineStatus) {
      elements.viewerOfflineStatus.hidden = true;
    }
    elements.viewerStage.replaceChildren();
  }

  function renderViewerLoading() {
    const loader = document.createElement("span");
    loader.className = "viewer-loader";
    loader.setAttribute("role", "status");
    loader.setAttribute("aria-label", "Đang tải ảnh");
    elements.viewerStage.replaceChildren(loader);
  }

  function renderViewerError(index) {
    const error = document.createElement("div");
    error.className = "viewer-error";
    const message = document.createElement("p");
    message.textContent = "Không tải được nội dung này.";
    const retry = document.createElement("button");
    retry.type = "button";
    retry.className = "button button-dark";
    retry.textContent = "Thử lại";
    retry.addEventListener("click", () => showViewer(index));
    error.append(message, retry);
    elements.viewerStage.replaceChildren(error);
  }

  function setViewerInfoVisible(visible) {
    elements.viewerShell.classList.toggle("show-info", visible);
    elements.viewerInfoToggle.setAttribute("aria-pressed", String(visible));
    elements.viewerInfoToggle.setAttribute("aria-label", visible ? "Ẩn thông tin" : "Hiện thông tin");
  }

  async function loadViewerImage(item, index, token) {
    const viewUrl = item.preview || item.url;
    const controller = new AbortController();
    state.viewerAbortController = controller;

    try {
      let blob = null;
      let fromCache = false;
      try {
        blob = await readCachedBlob(VIEWED_IMAGE_CACHE_NAME, viewUrl);
        fromCache = Boolean(blob);
      } catch {
        // Cache failures should not prevent a normal LAN request.
      }

      if (!blob) {
        const response = await fetchMediaResponse(viewUrl, controller.signal);
        blob = await response.blob();
      }
      if (token !== state.viewerLoadToken || controller.signal.aborted) {
        return;
      }

      state.viewerAbortController = null;
      state.viewerBlob = blob;
      state.viewerCacheUrl = viewUrl;
      state.viewerObjectUrl = URL.createObjectURL(blob);

      const image = document.createElement("img");
      image.alt = item.name;
      image.decoding = "async";
      image.addEventListener("load", () => {
        if (token !== state.viewerLoadToken) {
          return;
        }
        if (fromCache) {
          touchViewedImageCache(viewUrl, blob.size);
          if (elements.viewerOfflineStatus) {
            elements.viewerOfflineStatus.hidden = false;
          }
          return;
        }

        state.viewerCacheTimer = window.setTimeout(async () => {
          state.viewerCacheTimer = null;
          if (token !== state.viewerLoadToken || state.viewerCacheUrl !== viewUrl || state.viewerBlob !== blob) {
            return;
          }
          try {
            const stored = await storeViewedImage(viewUrl, blob);
            if (stored && token === state.viewerLoadToken && elements.viewerOfflineStatus) {
              elements.viewerOfflineStatus.hidden = false;
            }
          } catch {
            // Quota and browser policy errors leave the current viewer unaffected.
          }
        }, VIEWER_CACHE_DELAY_MS);
      }, { once: true });
      image.addEventListener("error", () => {
        if (token === state.viewerLoadToken) {
          image.removeAttribute("src");
          if (state.viewerObjectUrl) {
            URL.revokeObjectURL(state.viewerObjectUrl);
          }
          state.viewerObjectUrl = null;
          state.viewerBlob = null;
          state.viewerCacheUrl = null;
          renderViewerError(index);
        }
      }, { once: true });
      image.src = state.viewerObjectUrl;
      elements.viewerStage.replaceChildren(image);
    } catch (error) {
      if (error?.name !== "AbortError" && token === state.viewerLoadToken) {
        state.viewerAbortController = null;
        renderViewerError(index);
      }
    }
  }

  function showViewer(index) {
    const item = state.visibleItems[index];
    if (!item) {
      return;
    }

    releaseViewerMedia();
    state.viewerIndex = index;
    const token = state.viewerLoadToken;
    const viewerTotal = state.mode === "api" ? state.total : state.visibleItems.length;
    elements.viewerName.textContent = item.name;
    elements.viewerFolder.textContent = item.folder;
    elements.viewerDetails.textContent = itemDetail(item) || "Server chưa cung cấp metadata";
    elements.viewerInfoName.textContent = item.name;
    elements.viewerInfoFolder.textContent = item.folder;
    elements.viewerInfoType.textContent = `${item.type === "video" ? "Video" : "Ảnh"} · ${item.extension.toUpperCase()}`;
    elements.viewerOpenOriginal.href = item.url;
    elements.viewerCount.textContent = `${numberFormatter.format(index + 1)} / ${numberFormatter.format(viewerTotal)}`;
    elements.viewerPrevious.disabled = index === 0;
    elements.viewerNext.disabled = index >= viewerTotal - 1;

    if (!elements.viewerDialog.open) {
      elements.viewerDialog.showModal();
    }

    if (item.type === "image") {
      renderViewerLoading();
      loadViewerImage(item, index, token);
    } else {
      const video = document.createElement("video");
      video.controls = true;
      video.autoplay = true;
      video.playsInline = true;
      video.preload = "metadata";
      video.src = item.url;
      elements.viewerStage.append(video);
    }
  }

  async function moveViewer(offset) {
    let nextIndex = state.viewerIndex + offset;
    if (offset > 0 && nextIndex >= state.visibleItems.length && state.mode === "api" && state.hasMore) {
      try {
        await loadApiPage();
      } catch (error) {
        showConnectionError(error);
        elements.scanStatus.hidden = true;
        return;
      }
      nextIndex = state.viewerIndex + offset;
    }
    if (nextIndex >= 0 && nextIndex < state.visibleItems.length) {
      showViewer(nextIndex);
    }
  }

  function closeViewer() {
    releaseViewerMedia();
    state.viewerIndex = -1;
    setViewerInfoVisible(false);
    if (elements.viewerDialog.open) {
      elements.viewerDialog.close();
    }
  }

  function wait(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }

  async function downloadMediaItem(item, signal) {
    const response = await fetchMediaResponse(item.url, signal);
    const blob = await response.blob();
    if (signal?.aborted) {
      throw new DOMException("Đã dừng tải xuống", "AbortError");
    }

    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = objectUrl;
    link.download = item.name.replaceAll("/", "_").replaceAll("\\", "_") || "media";
    link.hidden = true;
    document.body.append(link);
    link.click();
    link.remove();
    await wait(350);
    URL.revokeObjectURL(objectUrl);
  }

  async function downloadViewerItem() {
    const item = state.visibleItems[state.viewerIndex];
    if (!item || elements.viewerDownload.disabled) {
      return;
    }

    const controller = new AbortController();
    elements.viewerDownload.disabled = true;
    try {
      await downloadMediaItem(item, controller.signal);
      showToast(`Đã gửi ${item.name} tới trình tải xuống.`);
    } catch (error) {
      if (error?.name !== "AbortError") {
        showToast(`Không tải được ${item.name}.`);
      }
    } finally {
      elements.viewerDownload.disabled = false;
    }
  }

  async function downloadSelectedItems() {
    const selectedItems = state.items.filter((item) => state.selectedIds.has(item.id));
    if (selectedItems.length === 0 || state.isDownloading) {
      return;
    }

    const controller = new AbortController();
    state.downloadAbortController = controller;
    state.isDownloading = true;
    elements.selectionBar.classList.add("is-busy");
    elements.selectionProgress.hidden = false;
    elements.selectionProgressBar.style.width = "0%";
    updateSelectionUi();

    let completed = 0;
    let failed = 0;
    for (const item of selectedItems) {
      if (controller.signal.aborted) {
        break;
      }
      const current = completed + failed + 1;
      elements.selectionProgress.textContent =
        `Đang chuẩn bị ${numberFormatter.format(current)} / ${numberFormatter.format(selectedItems.length)}`;
      try {
        await downloadMediaItem(item, controller.signal);
        completed += 1;
      } catch (error) {
        if (error?.name === "AbortError") {
          break;
        }
        failed += 1;
      }
      const processed = completed + failed;
      elements.selectionProgressBar.style.width = `${(processed / selectedItems.length) * 100}%`;
    }

    if (state.downloadAbortController === controller) {
      state.downloadAbortController = null;
      state.isDownloading = false;
      elements.selectionBar.classList.remove("is-busy");
      updateSelectionUi();
    }

    if (controller.signal.aborted) {
      showToast("Đã dừng tải xuống.");
      return;
    }

    elements.selectionProgress.textContent = failed > 0
      ? `Đã gửi ${numberFormatter.format(completed)} mục · ${numberFormatter.format(failed)} lỗi`
      : `Đã gửi ${numberFormatter.format(completed)} mục tới trình tải xuống`;
    elements.selectionProgressBar.style.width = "100%";
    showToast(failed > 0
      ? `Đã tải ${numberFormatter.format(completed)} mục, ${numberFormatter.format(failed)} mục bị lỗi.`
      : `Đã gửi ${numberFormatter.format(completed)} mục tới trình tải xuống.`);
  }

  function resetAlbumState() {
    closeViewer();
    exitSelectionMode();
    state.items = [];
    state.visibleItems = [];
    state.total = 0;
    state.stats = null;
    state.facets = { folders: [], dates: [] };
    state.hasMore = false;
    state.renderedCount = 0;
    state.viewerIndex = -1;
    state.isLoadingMore = false;
    clearMediaGrid();
    setMode(null);
  }

  async function connectAlbum({ force = false } = {}) {
    if (!state.endpoint) {
      return;
    }

    state.requestVersion += 1;
    const version = state.requestVersion;
    resetAlbumState();
    hideNotice();
    renderSkeletons();
    setLoading(true, state.isLocalServer ? "Đang tìm server LAN…" : "Đang kết nối kho ảnh…");

    try {
      try {
        await probeApi();
        if (version !== state.requestVersion) {
          return;
        }
        elements.scanStatusText.textContent = "Đang lập chỉ mục album…";
        await loadApiPage({ reset: true, force, version });
      } catch (error) {
        if (!(error instanceof ApiUnavailableError)) {
          throw error;
        }
        elements.scanStatusText.textContent = "Đang quét thư mục…";
        await scanDirectory(version);
      }

      if (version === state.requestVersion) {
        if (state.mode === "directory") {
          showLegacyServerNotice();
        } else {
          hideNotice();
        }
      }
    } catch (error) {
      if (version !== state.requestVersion) {
        return;
      }
      resetAlbumState();
      if (await restoreCachedCatalog()) {
        showOfflineNotice(error);
      } else {
        showConnectionError(error);
      }
    } finally {
      if (version === state.requestVersion) {
        setLoading(false);
        updateSummary();
        updateEmptyState();
      }
    }
  }

  let controlTimer = null;

  function reloadFromControls() {
    clearTimeout(controlTimer);
    if (state.mode === "api") {
      controlTimer = setTimeout(async () => {
        state.requestVersion += 1;
        const version = state.requestVersion;
        closeViewer();
        state.items = [];
        state.visibleItems = [];
        state.total = 0;
        state.hasMore = false;
        state.renderedCount = 0;
        renderSkeletons();
        setLoading(true, "Đang cập nhật kết quả…");
        try {
          await loadApiPage({ reset: true, version });
          hideNotice();
        } catch (error) {
          if (version === state.requestVersion) {
            resetAlbumState();
            if (await restoreCachedCatalog()) {
              showOfflineNotice(error);
            } else {
              showConnectionError(error);
            }
          }
        } finally {
          if (version === state.requestVersion) {
            setLoading(false);
            updateSummary();
            updateEmptyState();
          }
        }
      }, 280);
    } else if (state.mode === "directory" || state.mode === "offline") {
      refreshDirectoryItems(false);
    }
  }

  function applyEndpoint(endpoint) {
    state.endpoint = endpoint;
    state.baseUrl = endpointUrl(endpoint);
    state.isLocalServer = endpoint.kind === "local";
    state.view = "library";
    state.filter = "all";
    state.timelineFilters = { folder: "", year: "", month: "", day: "" };
    updateNavigationUi();
    loadHiddenItems();
    elements.endpointLabel.textContent = endpoint.label;
    elements.openCloud.hidden = state.isLocalServer;
    elements.noticeOpenDirect.hidden = state.isLocalServer;
    connectAlbum();
  }

  elements.timelineFilterButton.addEventListener("click", showTimelineFilterDialog);
  elements.filterClose.addEventListener("click", closeTimelineFilterDialog);
  elements.yearFilter.addEventListener("change", () => {
    const filters = readTimelineFilterForm();
    filters.month = "";
    filters.day = "";
    populateTimelineFilterDialog(filters);
  });
  elements.monthFilter.addEventListener("change", () => {
    const filters = readTimelineFilterForm();
    filters.day = "";
    populateTimelineFilterDialog(filters);
  });
  elements.filterForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const nextFilters = readTimelineFilterForm();
    if (JSON.stringify(nextFilters) === JSON.stringify(state.timelineFilters)) {
      closeTimelineFilterDialog();
      return;
    }
    exitSelectionMode();
    state.timelineFilters = nextFilters;
    closeTimelineFilterDialog();
    updateTimelineFilterUi();
    reloadFromControls();
  });
  elements.filterReset.addEventListener("click", () => {
    const hadActiveFilters = activeTimelineFilterCount() > 0;
    state.timelineFilters = { folder: "", year: "", month: "", day: "" };
    populateTimelineFilterDialog();
    updateTimelineFilterUi();
    if (hadActiveFilters) {
      closeTimelineFilterDialog();
      reloadFromControls();
    }
  });

  elements.openCloud.addEventListener("click", openDirectly);
  elements.themeToggle.addEventListener("click", () => {
    const nextTheme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    applyTheme(nextTheme, true);
  });
  elements.emptyConnect.addEventListener("click", () => connectAlbum());
  elements.noticeOpenDirect.addEventListener("click", openDirectly);
  elements.retryButton.addEventListener("click", () => connectAlbum());
  elements.refreshButton.addEventListener("click", () => connectAlbum({ force: true }));

  elements.searchInput.addEventListener("input", () => {
    if (state.selectionMode) {
      exitSelectionMode();
    }
    state.query = elements.searchInput.value;
    reloadFromControls();
  });

  for (const button of elements.navigationButtons) {
    button.addEventListener("click", () => {
      const nextView = button.dataset.navView;
      const nextFilter = button.dataset.navFilter;
      if (nextView === state.view && (nextView === "hidden" || nextFilter === state.filter)) {
        return;
      }
      exitSelectionMode();
      state.view = nextView;
      state.filter = nextFilter;
      updateNavigationUi();
      reloadFromControls();
    });
  }

  for (const button of elements.filterButtons) {
    button.addEventListener("click", () => {
      if (state.selectionMode) {
        exitSelectionMode();
      }
      state.filter = button.dataset.filter;
      updateNavigationUi();
      reloadFromControls();
    });
  }

  elements.sortSelect.addEventListener("change", () => {
    if (state.selectionMode) {
      exitSelectionMode();
    }
    state.sort = elements.sortSelect.value;
    reloadFromControls();
  });

  elements.sizeInput.addEventListener("input", () => {
    document.documentElement.style.setProperty("--tile-size", `${elements.sizeInput.value}px`);
  });

  elements.mediaGrid.addEventListener("click", (event) => {
    const groupButton = event.target.closest("[data-select-group]");
    if (groupButton) {
      toggleTimelineGroup(groupButton.dataset.selectGroup);
      return;
    }
    const card = event.target.closest(".media-card:not(.is-skeleton)");
    if (!card) {
      return;
    }
    const index = Number(card.dataset.index);
    if (state.selectionMode) {
      toggleItemSelection(index, event.shiftKey);
    } else if (event.target.closest(".selection-check")) {
      enterSelectionMode(index);
    } else {
      showViewer(index);
    }
  });

  elements.selectButton.addEventListener("click", () => enterSelectionMode());
  elements.selectionCancel.addEventListener("click", exitSelectionMode);
  elements.selectAllButton.addEventListener("click", toggleSelectAll);
  elements.hideSelected.addEventListener("click", () => applyHiddenAction(true));
  elements.restoreSelected.addEventListener("click", () => applyHiddenAction(false));
  elements.downloadSelected.addEventListener("click", downloadSelectedItems);

  elements.viewerClose.addEventListener("click", closeViewer);
  elements.viewerInfoToggle.addEventListener("click", () => {
    setViewerInfoVisible(!elements.viewerShell.classList.contains("show-info"));
  });
  elements.viewerInfoClose.addEventListener("click", () => setViewerInfoVisible(false));
  elements.viewerDownload.addEventListener("click", downloadViewerItem);
  elements.viewerPrevious.addEventListener("click", () => moveViewer(-1));
  elements.viewerNext.addEventListener("click", () => moveViewer(1));
  elements.viewerDialog.addEventListener("click", (event) => {
    if (event.target === elements.viewerDialog) {
      closeViewer();
    }
  });
  elements.viewerDialog.addEventListener("cancel", (event) => {
    event.preventDefault();
    closeViewer();
  });

  document.addEventListener("keydown", (event) => {
    if (elements.viewerDialog.open) {
      if (event.key === "ArrowLeft") {
        moveViewer(-1);
      } else if (event.key === "ArrowRight") {
        moveViewer(1);
      }
      return;
    }
    if (event.key === "/" && !event.metaKey && !event.ctrlKey && !event.altKey) {
      const target = event.target;
      if (!(target instanceof HTMLInputElement) && !(target instanceof HTMLTextAreaElement) && !(target instanceof HTMLSelectElement)) {
        event.preventDefault();
        elements.searchInput.focus();
      }
      return;
    }
    if (event.key === "Escape" && state.selectionMode) {
      exitSelectionMode();
    }
  });

  const observer = new IntersectionObserver(
    (entries) => {
      if (!entries.some((entry) => entry.isIntersecting) || state.isLoading) {
        return;
      }
      if (state.mode === "api") {
        loadApiPage().catch((error) => {
          showConnectionError(error);
          elements.scanStatus.hidden = true;
        });
      } else if (state.mode === "directory" || state.mode === "offline") {
        renderNextPage();
      }
    },
    { rootMargin: "500px 0px" },
  );
  observer.observe(elements.loadSentinel);

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./sw.js", { scope: "./", updateViaCache: "none" }).catch(() => {});
    }, { once: true });
  }

  const currentPageEndpoint = localPageEndpoint();
  const initialEndpoint = currentPageEndpoint || CLOUD_ENDPOINT;
  document.body.classList.toggle("is-local-server", Boolean(currentPageEndpoint));
  applyEndpoint(initialEndpoint);
})();
